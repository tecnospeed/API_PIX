const axios = require('axios');
const fs = require('fs');
const { bearerToken } = require('../constants.js');

function getApiUrl(useSandbox) {
  return useSandbox ? 'https://pix.tecnospeed.com.br/sandbox' : 'https://pix.tecnospeed.com.br/api/v1'; 
}

function makeRequest(apiUrl, token, additionalHeaders = {}) {
  const headers = {
    'Authorization': `Bearer ${token}`,
    'Content-Type': 'application/json',
    ...additionalHeaders
  };

  return axios.create({
    baseURL: apiUrl,
    headers
  });
}

async function createWebhook(webhookData, useSandbox = false) {
  try {
    const apiUrl = getApiUrl(useSandbox);
    const { onEvents, method, url, headers } = webhookData;

    const formData = new FormData();
    formData.append('onEvents', JSON.stringify(onEvents));
    formData.append('method', method);
    formData.append('url', url);
    formData.append('headers', JSON.stringify(headers));

    const response = await makeRequest(apiUrl, bearerToken, formData).post('/webhook');
    console.log('Webhook criado:', response.data);
  } catch (error) {
    console.error('Erro ao criar webhook:', error.response?.data);
  }
}

async function getWebhook(webhookId, useSandbox = false) {
  try {
    const apiUrl = getApiUrl(useSandbox);

    const response = await makeRequest(apiUrl, bearerToken).get(`/webhook/${webhookId}`);
    console.log('Detalhes do webhook:', response.data);
  } catch (error) {
    console.error('Erro ao obter webhook:', error.response?.data);
  }
}

async function updateWebhook(webhookId, webhookData, useSandbox = false) {
  try {
    const apiUrl = getApiUrl(useSandbox);

    const { onEvents, method, url, headers } = webhookData;

    const formData = new FormData();
    formData.append('onEvents', JSON.stringify(onEvents));
    formData.append('method', method);
    formData.append('url', url);
    formData.append('headers', JSON.stringify(headers));

    const response = await makeRequest(apiUrl, bearerToken, formData).put(`/webhook/${webhookId}`, formData);
    console.log('Webhook atualizado:', response.data);
  } catch (error) {
    console.error('Erro ao atualizar webhook:', error.response?.data);
  }
}

async function deleteWebhook(webhookId, useSandbox = false) {
  try {
    const apiUrl = getApiUrl(useSandbox);

    const response = await makeRequest(apiUrl, bearerToken).delete(`/webhook/${webhookId}`);
    console.log('Webhook excluído:', response.data);
  } catch (error) {
    console.error('Erro ao excluir webhook:', error.response?.data);
  }
}

const novoWebhook = {
  onEvents: [
    ['PIX_SUCCESSFUL'],
    ['PAYMENT_FAILED', 'PAYMENT_UPDATED']
  ],
  method: 'POST',
  url: 'https://meu-callback-url.com/webhook',
  headers: {
    'Content-Type': 'application/json'
  }
};

const webhookId = 'Id Webhook'; 

const useSandbox = true; 

createWebhook(novoWebhook, useSandbox);
//getWebhook(webhookId, useSandbox);
//updateWebhook(webhookId, { method: 'GET' }, useSandbox);
//deleteWebhook(webhookId, useSandbox);