const axios = require('axios');
const { bearerToken } = require('../constants.js');

async function getBilhetagem(dateStart, dateEnd, cpfCnpj, useSandbox = false) {
  try {
    const apiUrl = useSandbox
      ? 'https://pix.tecnospeed.com.br/sandbox/report'
      : 'https://pix.tecnospeed.com.br/api/v1/report';

    const params = {
      dateStart,
      dateEnd,
      cpfCnpj
    };

    const response = await axios.get(apiUrl, { params });
    console.log('Bilhetagem encontrada:', response.data);
  } catch (error) {
    console.error('Erro ao consultar bilhetagem:', error.response?.data);
  }
}

const dateStart = '2021-08-01'; 
const dateEnd = '2021-08-31'; 
const cpfCnpj = '01001001000113'; 

const useSandbox = true; 

getBilhetagem(dateStart, dateEnd, cpfCnpj, useSandbox);