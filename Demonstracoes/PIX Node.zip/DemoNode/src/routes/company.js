const axios = require('axios');
const { bearerToken } = require('../constants.js');

async function createCompany(companyData, useSandbox = true) {
  try {
    const apiUrl = useSandbox ? 'https://pix.tecnospeed.com.br/sandbox' : 'https://pix.tecnospeed.com.br/api/v1'; 

    const headers = {
      'Authorization': `Bearer ${bearerToken}`,
      'Content-Type': 'application/json'
    };

    const response = await axios.post(`${apiUrl}/companies`, companyData, { headers });
    console.log('Company criada:', response.data);
  } catch (error) {
    console.error('Erro ao criar company:', error.response?.data);
  }
}

async function getCompany(companyId, useSandbox = false) {
  try {
    const apiUrl = useSandbox ? 'https://pix.tecnospeed.com.br/sandbox' : 'https://pix.tecnospeed.com.br/api/v1'; 
    

    const headers = {
      'Authorization': `Bearer ${bearerToken}`
    };

    const response = await axios.get(`${apiUrl}/companies/${companyId}`, { headers });
    console.log('Detalhes da company:', response.data);
  } catch (error) {
    console.error('Erro ao obter company:', error.response?.data);
  }
}


async function updateCompany(companyId, companyData, useSandbox = false) {
  try {
    const apiUrl = useSandbox ? 'https://pix.tecnospeed.com.br/sandbox' : 'https://pix.tecnospeed.com.br/api/v1'; 
    
    const headers = {
      'Authorization': `Bearer ${bearerToken}`,
      'Content-Type': 'application/json'
    };

    const response = await axios.put(`${apiUrl}/companies/${companyId}`, companyData, { headers });
    console.log('Company atualizada:', response.data);
  } catch (error) {
    console.error('Erro ao atualizar company:', error.response?.data);
  }
}


async function deleteCompany(companyId, useSandbox = false) {
  try {
    const apiUrl = useSandbox ? 'https://pix.tecnospeed.com.br/sandbox' : 'https://pix.tecnospeed.com.br/api/v1'; 
    

    const headers = {
      'Authorization': `Bearer ${bearerToken}`
    };

    const response = await axios.delete(`${apiUrl}/companies/${companyId}`, { headers });
    console.log('Company excluída:', response.data);
  } catch (error) {
    console.error('Erro ao excluir company:', error.response?.data);
  }
}

const novaCompany = {
  name: 'Minha Company',
  email: 'company@example.com',
  cpfCnpj: '12749459923',
  city: 'Minha Cidade',
  state: 'PR',
  zipcode: '12345678',
  accounts: [
    { type: 'Conta Corrente', number: '12345-6', agency: '7890' },
    { type: 'Conta Poupança', number: '98765-4', agency: '4321' }
  ]
};

const companyId = '61c22bc9-b0e8-459f-9cd7-0f84427f5c19';

const useSandbox = true;

createCompany(novaCompany, useSandbox);
//getCompany(companyId, useSandbox);
//updateCompany(companyId, { name: 'Minha Company Atualizada' }, useSandbox);
//deleteCompany(companyId, useSandbox);