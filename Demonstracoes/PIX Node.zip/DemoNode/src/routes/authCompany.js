const axios = require('axios');

async function authenticateCompany(clientId, clientSecret) {
  try {
    const apiUrl = 'https://pix.tecnospeed.com.br/oauth2/token'; 

    const credentials = `${clientId}:${clientSecret}`;
    const base64Credentials = Buffer.from(credentials).toString('base64');
    const grantType = 'client_credentials';
    const role = 'company';

    const formData = new URLSearchParams();
    formData.append('grant_type', grantType);
    formData.append('role', role);

    const response = await axios.post(apiUrl, formData, {
      headers: {
        'Authorization': `Basic ${base64Credentials}`,
        'Content-Type': 'application/x-www-form-urlencoded'
      }
    });

    console.log('Token de acesso da Company:', response.data.access_token);
  } catch (error) {
    console.error('Erro na autenticação da Company:', error.response?.data);
  }
}

const clientId = ''; 
const clientSecret = ''; 

authenticateCompany(clientId, clientSecret);