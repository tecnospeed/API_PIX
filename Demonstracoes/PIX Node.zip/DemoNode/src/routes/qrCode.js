const axios = require('axios');
const { bearerToken } = require('../constants.js');

async function getPIXById(pixId, useSandbox = false, type = 'html', size = 400) {
  try {
    const apiUrl = useSandbox
      ? `https://pix.tecnospeed.com.br/sandbox/qr/${pixId}`
      : `https://pix.tecnospeed.com.br/api/v1/qr/${pixId}`;

    const params = {
      type,
      size
    };

    const response = await axios.get(apiUrl, { params });
    console.log('PIX encontrado:', response.data);
  } catch (error) {
    console.error('Erro ao consultar PIX:', error.response?.data);
  }
}

const pixId = '4881b7c6-31aa-11ee-be56-0242ac120002'; 

const useSandbox = true; 
const type = 'html'; 
const size = 400; 

getPIXById(pixId, useSandbox, type, size);