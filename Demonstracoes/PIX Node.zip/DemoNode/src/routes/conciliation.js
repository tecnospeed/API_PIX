const axios = require('axios');
const fs = require('fs');
const { bearerToken } = require('../constants.js');

async function uploadFile(fileData, useSandbox = false) {
  try {
    const apiUrl = useSandbox
      ? 'https://pix.tecnospeed.com.br/sandbox/conciliations/upload'
      : 'https://pix.tecnospeed.com.br/api/v1/conciliations/upload';

    const response = await axios.post(apiUrl, fileData, {
      headers: {
        'Authorization': `Bearer ${bearerToken}`,
        'Content-Type': 'multipart/form-data'
      }
    });
    console.log('Conciliação de arquivo de retorno realizada:', response.data);
  } catch (error) {
    console.error('Erro ao realizar conciliação de arquivo de retorno:', error.response?.data);
  }
}

async function getConciliation(conciliationId, useSandbox = false) {
  try {
    const apiUrl = useSandbox
      ? `https://pix.tecnospeed.com.br/sandbox/conciliations/${conciliationId}`
      : `https://pix.tecnospeed.com.br/api/v1/conciliations/${conciliationId}`;

    const response = await axios.get(apiUrl, {
      headers: {
        'Authorization': `Bearer ${bearerToken}`
      }
    });
    console.log('Detalhes da conciliação de arquivo de retorno:', response.data);
  } catch (error) {
    console.error('Erro ao consultar conciliação de arquivo de retorno:', error.response?.data);
  }
}

const filePath = 'caminho/do/arquivo_de_retorno.txt'; 

const useSandbox = true; 

const fileData = new FormData();
fileData.append('file', fs.createReadStream(filePath));

uploadFile(fileData, useSandbox);
getConciliation('uuid_da_conciliacao', useSandbox);