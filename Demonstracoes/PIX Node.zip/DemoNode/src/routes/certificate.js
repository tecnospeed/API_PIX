const axios = require('axios');
const fs = require('fs');
const path = require('path')
const { bearerToken } = require('../constants.js');
const FormData = require('form-data');
const certificateRoutes = path.resolve(__dirname, '../certificates/certificado_convertido.pfx');

function getApiUrl(useSandbox) {
  return useSandbox ? 'https://pix.tecnospeed.com.br/sandbox' : 'https://pix.tecnospeed.com.br/api/v1'; 
}

function makeRequest(apiUrl, token, additionalHeaders = {}) {
  const headers = {
    'Authorization': `Bearer ${token}`,
    'Content-Type': 'application/json',
    ...additionalHeaders
  };

  return axios.create({
    baseURL: apiUrl,
    headers
  });
}

async function createCertificate(certificateData, useSandbox = false) {
  try {
    const apiUrl = getApiUrl(useSandbox);

    const { description, password, extension, accountId, file, key } = certificateData;

    const formData = new FormData();
    formData.append('description', description);
    formData.append('accountId', accountId);
    formData.append('file', fs.createReadStream(file.path)); // Lendo o arquivo .pfx diretamente como um arquivo binário
    if (extension === 'p12' || extension === 'pfx') {
      formData.append('password', password);
    }
    if (key) {
      formData.append('key', fs.createReadStream(key.path));
    }

    const response = await makeRequest(apiUrl, bearerToken, formData).post('/certificate/upload/');
    console.log('Certificado criado:', response.data);
  } catch (error) {
    console.error('Erro ao criar certificado:', error.response?.data);
  }
}


async function getCertificate(useSandbox = false) {
  try {
    const apiUrl = getApiUrl(useSandbox);

    const response = await makeRequest(apiUrl, bearerToken).get(`/certificate`);
    console.log('Detalhes do certificado:', response.data);
  } catch (error) {
    console.error('Erro ao obter certificado:', error.response?.data);
  }
}


async function updateCertificate(certificateId, certificateData, useSandbox = false) {
  try {
    const apiUrl = getApiUrl(useSandbox); 

    const { description, password, extension, file, key } = certificateData;

    const formData = new FormData();
    formData.append('description', description);
    formData.append('file', fs.createReadStream(file.path));
    if (extension === 'p12' || extension === 'pfx') {
      formData.append('password', password);
    }
    if (key) {
      formData.append('key', fs.createReadStream(key.path));
    }

    const response = await makeRequest(apiUrl, bearerToken, formData).put(`/certificate/${certificateId}`, formData);
    console.log('Certificado atualizado:', response.data);
  } catch (error) {
    console.error('Erro ao atualizar certificado:', error.response?.data);
  }
}

async function deleteCertificate(certificateId, useSandbox = false) {
  try {
    const apiUrl = getApiUrl(useSandbox);

    const response = await makeRequest(apiUrl, bearerToken).delete(`/certificate/${certificateId}`);
    console.log('Certificado excluído:', response.data);
  } catch (error) {
    console.error('Erro ao excluir certificado:', error.response?.data);
  }
}

async function downloadCertificate(accountId, extension, useSandbox = false) {
  try {
    const apiUrl = getApiUrl(useSandbox);
    const url = `/certificate/download/${accountId}/${extension}`;

    const response = await makeRequest(apiUrl, bearerToken).get(url, {
      responseType: 'arraybuffer', 
    });

    const certificatePath = path.resolve(__dirname, '../certificates', `downloaded_certificate.${extension}`);
    fs.writeFileSync(certificatePath, response.data);

    console.log('Certificado baixado e salvo em:', certificatePath);
  } catch (error) {
    console.error('Erro ao baixar certificado:', error.response?.data);
  }
}

async function convertPfxToPem(certificateData, useSandbox = false) {
  try {
    const apiUrl = getApiUrl(useSandbox);
    const url = '/pfxtopem';

    const { description, password, extension, accountId, file } = certificateData;

    const formData = new FormData();
    formData.append('description', description);
    formData.append('password', password);
    formData.append('extension', extension);
    formData.append('accountId', accountId);
    formData.append('file', fs.createReadStream(file.path));

    const response = await makeRequest(apiUrl, bearerToken, formData).post(url, formData);
    console.log('Certificado convertido para PEM:', response.data);
  } catch (error) {
    console.error('Erro ao converter certificado para PEM:', error.response?.data);
  }
}

async function validateCertificate(certificateData, useSandbox = false) {
  try {
    const apiUrl = getApiUrl(useSandbox);
    const url = '/validate';

    const { description, password, extension, accountId, file, key } = certificateData;

    const formData = new FormData();
    formData.append('description', description);
    formData.append('password', password);
    formData.append('extension', extension);
    formData.append('accountId', accountId);
    formData.append('file', fs.createReadStream(file.path));
    if (key) {
      formData.append('key', fs.createReadStream(key.path));
    }

    const response = await makeRequest(apiUrl, bearerToken, formData).post(url, formData);
    console.log('Certificado validado:', response.data);
  } catch (error) {
    console.error('Erro ao validar certificado:', error.response?.data);
  }
}

const newCertificate = {
  description: 'Meu Certificado',
  password: 'minha_senha',
  extension: 'pfx',
  accountId: '',
  file: {
    path: certificateRoutes,
  },
  key: {
    path: path.resolve(__dirname, '..', 'certificates', 'arquivo.key'),
  }
};

const convertCertificateData = {
  description: 'Meu Certificado Convertido',
  password: 'minha_senha',
  extension: 'pem',
  accountId: 'UUID_da_conta',
  file: {
    path: certificateRoutes,
  },
};

const validateCertificateData = {
  description: 'Meu Certificado Validado',
  password: 'minha_senha',
  extension: 'pfx',
  accountId: 'UUID_da_conta',
  file: {
    path: certificateRoutes,
  },
  key: {
    path: path.resolve(__dirname, '..', 'certificates', 'arquivo.key'),
  },
};

const certificateId = 'Informar ID do certificado';
const extension = 'pfx';

const useSandbox = true; 

createCertificate(newCertificate, useSandbox);
//getCertificate(useSandbox);
//updateCertificate(certificateId, { description: 'Meu Certificado Atualizado' }, useSandbox);
//deleteCertificate(certificateId, useSandbox);
//downloadCertificate(accountId, extension, useSandbox);
//convertPfxToPem(convertCertificateData, useSandbox);
//validateCertificate(validateCertificateData, useSandbox);