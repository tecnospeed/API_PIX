const axios = require('axios');
const fs = require('fs');
const { bearerToken } = require('../constants.js');

function getApiUrl(useSandbox) {
  return useSandbox ? 'https://pix.tecnospeed.com.br/sandbox' : 'https://pix.tecnospeed.com.br/api/v1'; 
}

function makeRequest(apiUrl, token, additionalHeaders = {}) {
  const headers = {
    'Authorization': `Bearer ${token}`,
    'Content-Type': 'application/json',
    ...additionalHeaders
  };

  return axios.create({
    baseURL: apiUrl,
    headers
  });
}

async function createPixCharge(chargeData, useSandbox = false) {
  try {
    const apiUrl = getApiUrl(useSandbox);
    const { accountId, description, tags, calendar, payer, value, aditionalInformation } = chargeData;

    const requestData = {
      accountId,
      description,
      tags,
      calendar,
      payer,
      value,
      aditionalInformation
    };

    const response = await makeRequest(apiUrl, bearerToken).post('pix/charge', requestData);
    console.log('Pix cobrança criado:', response.data);
  } catch (error) {
    console.error('Erro ao Pix cobrança', error.response?.data);
  }
}

async function getPixCharge(chargeId, useSandbox = false) {
  try {
    const apiUrl = getApiUrl(useSandbox);

    const response = await makeRequest(apiUrl, bearerToken).get(`pix/charges${chargeId}`);
    console.log('Detalhes do Pix:', response.data);
  } catch (error) {
    console.error('Erro ao obter as informações do Pix:', error.response?.data);
  }
}

async function updateCharge(chargeId, chargeData, useSandbox = false) {
  try {
    const apiUrl = getApiUrl(useSandbox);

    const { accountId, description, tags, calendar, payer, value, aditionalInformation } = chargeData;

    const requestData = {
      accountId,
      description,
      tags,
      calendar,
      payer,
      value,
      aditionalInformation
    };

    const response = await makeRequest(apiUrl, bearerToken).put(`pix/charge/${chargeId}`, requestData);
    console.log('Charge atualizada:', response.data);
  } catch (error) {
    console.error('Erro ao atualizar charge:', error.response?.data);
  }
}

async function deletePixCharge(chargeId, useSandbox = false) {
  try {
    const apiUrl = getApiUrl(useSandbox);

    const response = await makeRequest(apiUrl, bearerToken).delete(`pix/charge/${chargeId}`);
    console.log('Pix excluído:', response.data);
  } catch (error) {
    console.error('Erro ao excluir o Pix:', error.response?.data);
  }
}


const novaCharge = {
  accountId: '74099a04-31a9-11ee-be56-0242ac120002',
  description: 'Descrição da charge',
  tags: ['tag1', 'tag2'],
  calendar: {
    dueDate: '2023-08-10T00:00:00Z',
    expirationDate: '2023-08-11T00:00:00Z'
  },
  payer: {
    cpfCnpj: '12345678901',
    name: 'Nome do Pagador',
    email: 'pagador@example.com',
    street: 'Rua do Pagador',
    city: 'Cidade do Pagador',
    state: 'UF',
    zipcode: '12345678'
  },
  value: {
    original: 100.0,
    final: 90.0,
    currency: 'BRL'
  },
  aditionalInformation: [
    { key: 'chave1', value: 'valor1' },
    { key: 'chave2', value: 'valor2' }
  ]
};

const chargeId = '74099a04-31a9-11ee-be56-0242ac120002'; 

const useSandbox = true; 

createPixCharge(novaCharge, useSandbox);
getPixCharge(chargeId, useSandbox);
updateCharge(chargeId, { value: { final: 80.0 } }, useSandbox);
deletePixCharge(chargeId, useSandbox);