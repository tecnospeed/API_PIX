const axios = require('axios');
const { bearerToken } = require('../constants.js');

async function payPIX(paymentData, useSandbox = false) {
  try {
    const apiUrl = useSandbox
      ? 'https://pix.tecnospeed.com.br/sandbox/payments'
      : 'https://pix.tecnospeed.com.br/api/v1/payments';

    const response = await axios.post(apiUrl, paymentData, {
      headers: {
        'Authorization': `Bearer ${bearerToken}`,
        'Content-Type': 'application/json'
      }
    });
    console.log('Pagamento de PIX realizado:', response.data);
  } catch (error) {
    console.error('Erro ao realizar pagamento de PIX:', error.response?.data);
  }
}

async function getPayment(paymentId, useSandbox = false) {
  try {
    const apiUrl = useSandbox
      ? `https://pix.tecnospeed.com.br/sandbox/payments/${paymentId}`
      : `https://pix.tecnospeed.com.br/api/v1/payments/${paymentId}`;

    const response = await axios.get(apiUrl, {
      headers: {
        'Authorization': `Bearer ${bearerToken}`
      }
    });
    console.log('Detalhes do pagamento de PIX:', response.data);
  } catch (error) {
    console.error('Erro ao consultar pagamento de PIX:', error.response?.data);
  }
}

const paymentData = {
  amount: 100.0, 
  accountId: 'ac67ab60-31aa-11ee-be56-0242ac120002',
  emv: 'codigo_do_qrcode' 
};

const paymentId = 'ac67ab60-31aa-11ee-be56-0242ac120002'; 

const useSandbox = true; 

payPIX(paymentData, useSandbox);
getPayment(paymentId, useSandbox);