const axios = require('axios');
const fs = require('fs');
const { bearerToken } = require('../constants.js');

function getApiUrl(useSandbox) {
  return useSandbox ? 'https://pix.tecnospeed.com.br/sandbox' : 'https://pix.tecnospeed.com.br/api/v1';
}

function makeRequest(apiUrl, token, additionalHeaders = {}) {
  const headers = {
    'Authorization': `Bearer ${token}`,
    'Content-Type': 'application/json',
    ...additionalHeaders
  };

  return axios.create({
    baseURL: apiUrl,
    headers
  });
}

async function createPixDynamic(dynamicData, useSandbox = false) {
  try {
    const apiUrl = getApiUrl(useSandbox);

    const { accountId, description, tags, amount, duration, payerName, payerCpfCnpj, aditionalInformation } = dynamicData;

    const requestData = {
      accountId,
      description,
      tags,
      amount,
      duration,
      payerName,
      payerCpfCnpj,
      aditionalInformation
    };

    const response = await makeRequest(apiUrl, bearerToken).post('/pix/dynamic', requestData);
    console.log('Dynamic criado:', response.data);
  } catch (error) {
    console.error('Erro ao criar dynamic:', error.response?.data);
  }
}

async function getDynamic(pixDynamicId, useSandbox = false) {
  try {
    const apiUrl = getApiUrl(useSandbox); 

    const response = await makeRequest(apiUrl, bearerToken).get(`/pix/dynamic/${pixDynamicId}`);
    console.log('Detalhes do dynamic:', response.data);
  } catch (error) {
    console.error('Erro ao obter dynamic:', error.response?.data);
  }
}

async function updateDynamic(pixDynamicId, dynamicData, useSandbox = false) {
  try {
    const apiUrl = getApiUrl(useSandbox);

    const { accountId, description, tags, amount, duration, payerName, payerCpfCnpj, aditionalInformation } = dynamicData;

    const requestData = {
      accountId,
      description,
      tags,
      amount,
      duration,
      payerName,
      payerCpfCnpj,
      aditionalInformation
    };

    const response = await makeRequest(apiUrl, bearerToken).put(`/pix/dynamic/${pixDynamicId}`, requestData);
    console.log('Dynamic atualizado:', response.data);
  } catch (error) {
    console.error('Erro ao atualizar dynamic:', error.response?.data);
  }
}

async function deleteDynamic(pixDynamicId, useSandbox = false) {
  try {
    const apiUrl = getApiUrl(useSandbox); 

    const response = await makeRequest(apiUrl, bearerToken).delete(`/pix/dynamic/${pixDynamicId}`);
    console.log('Dynamic excluído:', response.data);
  } catch (error) {
    console.error('Erro ao excluir dynamic:', error.response?.data);
  }
}

const novoDynamic = {
  accountId: 'e30bbb86-31a8-11ee-be56-0242ac120002',
  description: 'Descrição do dynamic',
  tags: ['tag1', 'tag2'],
  amount: 100.0,
  duration: 3600,
  payerName: 'Nome do Pagador',
  payerCpfCnpj: '12749459923',
  aditionalInformation: [
    { key: 'chave1', value: 'valor1' },
    { key: 'chave2', value: 'valor2' }
  ]
};

const pixDynamicId = 'e30bbb86-31a8-11ee-be56-0242ac120002'; 

const useSandbox = true; 

createPixDynamic(novoDynamic, useSandbox);
//getDynamic(pixDynamicId, useSandbox);
//updateDynamic(pixDynamicId, { amount: 200.0 }, useSandbox);
//deleteDynamic(pixDynamicId, useSandbox);



