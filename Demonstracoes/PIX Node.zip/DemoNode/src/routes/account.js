const axios = require('axios');
const { bearerToken } = require('../constants.js');

async function createAccount(accountData, useSandbox = false) {
  try {
    const apiUrl = useSandbox ? 'https://pix.tecnospeed.com.br/sandbox' : 'https://pix.tecnospeed.com.br/api/v1';
    const headers = {
      'Authorization': `Bearer ${bearerToken}`,
      'Content-Type': 'application/json'
    };

    const response = await axios.post(`${apiUrl}/accounts`, accountData, { headers });
    console.log('Conta criada:', response.data);
  } catch (error) {
    console.error('Erro ao criar conta:', error.response?.data);
  }
}

async function getAccount(accountId, useSandbox = false) {
  try {
    const apiUrl = useSandbox ? 'https://pix.tecnospeed.com.br/sandbox' : 'https://pix.tecnospeed.com.br/api/v1';  

    const headers = {
      'Authorization': `Bearer ${bearerToken}`
    };

    const response = await axios.get(`${apiUrl}/accounts/${accountId}`, { headers });
    console.log('Detalhes da conta:', response.data);
  } catch (error) {
    console.error('Erro ao obter conta:', error.response?.data);
  }
}


async function updateAccount(accountId, accountData, useSandbox = false) {
  try {
    const apiUrl = useSandbox ? 'https://pix.tecnospeed.com.br/sandbox' : 'https://pix.tecnospeed.com.br/api/v1';  

    const headers = {
      'Authorization': `Bearer ${bearerToken}`,
      'Content-Type': 'application/json'
    };

    const response = await axios.put(`${apiUrl}/accounts/${accountId}`, accountData, { headers });
    console.log('Conta atualizada:', response.data);
  } catch (error) {
    console.error('Erro ao atualizar conta:', error.response?.data);
  }
}

async function deleteAccount(accountId, useSandbox = false) {
  try {
    const apiUrl = useSandbox ? 'https://pix.tecnospeed.com.br/sandbox' : 'https://pix.tecnospeed.com.br/api/v1';  

    const headers = {
      'Authorization': `Bearer ${bearerToken}`
    };

    const response = await axios.delete(`${apiUrl}/accounts/${accountId}`, { headers });
    console.log('Conta inativada:', response.data);
  } catch (error) {
    console.error('Erro ao inativar a conta:', error.response?.data);
  }
}

const novaAccount = {
  bankCode: '001',
  bankAccount: '789532',
  pixKey: 'contato@empresa.com',
  clientId: '123456789abcdefjdd',
  clientKey: '123456789abcdefjdd',
  clientSecret: '123456789abcdefjdd',
};

const accountId = 1;

const useSandbox = true;

createAccount(novaAccount, useSandbox);
//getAccount(accountId, useSandbox);
//updateAccount(accountId, { pixKey: 'novo-email@empresa.com' }, useSandbox);
//deleteAccount(accountId, useSandbox);