const axios = require('axios');
const fs = require('fs');
const { bearerToken } = require('../constants.js');

function getApiUrl(useSandbox) {
  return useSandbox ? 'https://pix.tecnospeed.com.br/sandbox/users' : 'https://pix.tecnospeed.com.br/api/v1/users'; 
}

function makeRequest(apiUrl, token, additionalHeaders = {}) {
  const headers = {
    'Authorization': `Bearer ${token}`,
    'Content-Type': 'application/json',
    ...additionalHeaders
  };

  return axios.create({
    baseURL: apiUrl,
    headers
  });
}

async function createUser(userData, useSandbox = false) {
  try {
    const apiUrl = getApiUrl(useSandbox);

    const { name, email, description, scopes, file } = userData;

    const formData = new FormData();
    formData.append('name', name);
    formData.append('email', email);
    formData.append('description', description || ''); 
    formData.append('scopes', JSON.stringify(scopes));
    if (file) {
      formData.append('file', fs.createReadStream(file.path));
    }

    const response = await makeRequest(apiUrl, bearerToken, formData).post('/users');
    console.log('Usuário criado:', response.data);
  } catch (error) {
    console.error('Erro ao criar usuário:', error.response?.data);
  }
}

async function getUser(userId, useSandbox = false) {
  try {
    const apiUrl = getApiUrl(useSandbox); 

    const response = await makeRequest(apiUrl, bearerToken).get(`/users/${userId}`);
    console.log('Detalhes do usuário:', response.data);
  } catch (error) {
    console.error('Erro ao obter usuário:', error.response?.data);
  }
}

async function updateUser(userId, userData, useSandbox = false) {
  try {
    const apiUrl = getApiUrl(useSandbox);

    const { name, email, description, scopes, file } = userData;

    const formData = new FormData();
    formData.append('name', name);
    formData.append('email', email);
    formData.append('description', description || ''); 
    formData.append('scopes', JSON.stringify(scopes));
    if (file) {
      formData.append('file', fs.createReadStream(file.path));
    }

    const response = await makeRequest(apiUrl, bearerToken, formData).put(`/users/${userId}`, formData);
    console.log('Usuário atualizado:', response.data);
  } catch (error) {
    console.error('Erro ao atualizar usuário:', error.response?.data);
  }
}

async function deleteUser(userId, useSandbox = false) {
  try {
    const apiUrl = getApiUrl(useSandbox); 
    const response = await makeRequest(apiUrl, bearerToken).delete(`/users/${userId}`);
    console.log('Usuário excluído:', response.data);
  } catch (error) {
    console.error('Erro ao excluir usuário:', error.response?.data);
  }
}

const novoUser = {
  name: 'Meu Usuário',
  email: 'usuario@example.com',
  description: 'Descrição do usuário',
  scopes: ['api-access/pix.create', 'api-access/payments.list']
};

const userId = 'UserID'; 

const useSandbox = true; 

createUser(novoUser, useSandbox);
//getUser(userId, useSandbox);
//updateUser(userId, { name: 'Meu Usuário Atualizado' }, useSandbox);
//deleteUser(userId, useSandbox);