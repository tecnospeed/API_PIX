const axios = require('axios');

async function authenticateSoftwareHouse(email, password) {
  try {
    const apiUrl = 'https://pix.tecnospeed.com.br/oauth2/token';

    const credentials = `${email}:${password}`;
    const base64Credentials = Buffer.from(credentials).toString('base64');
    const grantType = 'client_credentials';
    const role = 'software_house';

    const formData = new URLSearchParams();
    formData.append('grant_type', grantType);
    formData.append('role', role);

    const response = await axios.post(apiUrl, formData, {
      headers: {
        'Authorization': `Basic ${base64Credentials}`,
        'Content-Type': 'application/x-www-form-urlencoded'
      }
    });

    console.log('Token de acesso:', response.data.access_token);
  } catch (error) {
    console.error('Erro na autenticação:', error.response?.data);
  }
}

const email = ''; 
const password = ''; 

authenticateSoftwareHouse(email, password);