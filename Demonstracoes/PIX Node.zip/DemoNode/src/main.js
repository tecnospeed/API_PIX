const api = require('./routes/account');

function main (){
  return api
}

main()