﻿Imports System.IO
Imports System.Text
Imports Nancy.Json
Imports Newtonsoft.Json
Imports Newtonsoft.Json.Linq
Imports RestSharp

Public Class Form1

    'Definindo as "ações" da demonstração
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Public Function AutenticaSH() As Object
        Return New With {Key .grant_type = "client_credentials", Key .role = "software_house"}
    End Function

    Public Function CamposCompany() As Object
        Return New With {
            Key .zipcode = "87080430", Key .name = "Teste", Key .email = "tecno@teste.com.br", Key .cpfCnpj = "01001001000113", Key .city = "Maringá", Key .state = "PR"
                        }
    End Function

    Public Function AutenticaCompany() As Object
        Return New With {
            Key .grant_type = "client_credentials", Key .role = "company"
                        }
    End Function

    Public Function CamposConta() As Object
        Return New With {Key .bankAccount = "12354", Key .bankAgency = "0001", Key .bankCode = "001", Key .clientId = "a477ed3c-0000-111-2222-52bcd6309131", Key .clientSecret = "9dc84cc8-2222-0000-5555-4378489340e7", Key .pixKey = "(99)999999999"
    }
    End Function

    Public Function CamposPix() As Object
        Return New With {Key .accountId = boxIdConta.Text, Key .payerCpfCnpj = "01001001000113", Key .payerName = "Teste Pagador", Key .amount = 1.0
    }
    End Function

    Public Function CamposPixCobranca() As Object
        Return New With {Key .accountId = "", Key .description = "01001001000113", Key .tags = "", Key .calendar = "", Key .payer = "{", Key .cpfCnpj = "70682370029", Key .name = "JOSE DA SILVA", Key .email = "teste@teste.com.br", Key .street = "RUA TESTE 500", Key .city = "Maringá", Key .state = "pr", Key .zipcode = "87080430" & "}"
    }
    End Function
    Private Sub BtnExemploSh_Click(sender As Object, e As EventArgs) Handles btnExemploSh.Click


        textoResposta.Text = ""
        Dim objCamposSH = AutenticaSH()
        Dim js As JavaScriptSerializer = New JavaScriptSerializer()
        js.Serialize(objCamposSH)
        textoEntrada.Text = JsonConvert.SerializeObject(objCamposSH, Formatting.Indented)

    End Sub

    Private Sub btnAutenticaExemploCompany_Click(sender As Object, e As EventArgs) Handles btnAutenticaExemploCompany.Click
        textoResposta.Text = ""
        Dim objCamposCompany = AutenticaCompany()
        Dim js As JavaScriptSerializer = New JavaScriptSerializer()
        js.Serialize(objCamposCompany)
        textoEntrada.Text = JsonConvert.SerializeObject(objCamposCompany, Formatting.Indented)

    End Sub

    Private Sub btnExemploCompany_Click(sender As Object, e As EventArgs) Handles btnExemploCompany.Click
        textoResposta.Text = ""
        Dim ObjCamposCompany = CamposCompany()
        Dim js As JavaScriptSerializer = New JavaScriptSerializer()
        js.Serialize(ObjCamposCompany)
        textoEntrada.Text = JsonConvert.SerializeObject(ObjCamposCompany, Formatting.Indented)
    End Sub

    Private Sub button4_Click(sender As Object, e As EventArgs) Handles button4.Click
        textoResposta.Text = ""
        Dim ObjCamposCompany = CamposCompany()
        Dim js As JavaScriptSerializer = New JavaScriptSerializer()
        js.Serialize(ObjCamposCompany)
        textoEntrada.Text = JsonConvert.SerializeObject(ObjCamposCompany, Formatting.Indented)
    End Sub

    Private Sub button5_Click(sender As Object, e As EventArgs)
        textoResposta.Text = ""
        Dim ObjCamposCompany = CamposCompany()
        Dim js As JavaScriptSerializer = New JavaScriptSerializer()
        js.Serialize(ObjCamposCompany)
        textoEntrada.Text = JsonConvert.SerializeObject(ObjCamposCompany, Formatting.Indented)
    End Sub

    Private Sub button7_Click(sender As Object, e As EventArgs) Handles button7.Click

    End Sub

    Private Sub tabPage2_Click(sender As Object, e As EventArgs) Handles tabPage2.Click

    End Sub

    Private Sub btnExemploConta_Click(sender As Object, e As EventArgs) Handles btnExemploConta.Click
        textoResposta.Text = ""
        Dim ObjCamposConta = CamposConta()
        Dim js As JavaScriptSerializer = New JavaScriptSerializer()
        js.Serialize(ObjCamposConta)
        textoEntrada.Text = JsonConvert.SerializeObject(ObjCamposConta, Formatting.Indented)
    End Sub

    Private Sub button10_Click(sender As Object, e As EventArgs) Handles button10.Click

        textoResposta.Text = ""
        Dim ObjCamposConta = CamposConta()
        Dim js As JavaScriptSerializer = New JavaScriptSerializer()
        js.Serialize(ObjCamposConta)
        textoEntrada.Text = JsonConvert.SerializeObject(ObjCamposConta, Formatting.Indented)

    End Sub

    Private Sub btnExemploPix_Click(sender As Object, e As EventArgs) Handles btnExemploPix.Click

        textoResposta.Text = ""
        Dim ObjCamposPix = CamposPix()
        Dim js As JavaScriptSerializer = New JavaScriptSerializer()
        js.Serialize(ObjCamposPix)
        textoEntrada.Text = JsonConvert.SerializeObject(ObjCamposPix, Formatting.Indented)

    End Sub

    Private Async Sub btnAutenticaSh_Click(sender As Object, e As EventArgs) Handles btnAutenticaSh.Click

        Dim url As String = ""
        Dim email As String = boxShEmail.Text
        Dim password As String = boxShSenha.Text
        Dim objCamposAutenticar = textoEntrada.Text
        Dim toBse64 As String = email & ":" & password
        Dim textoAsBytes As Byte() = System.Text.Encoding.ASCII.GetBytes(toBse64)
        Dim encodeBase64 As String = System.Convert.ToBase64String(textoAsBytes)

        'Forma de difinir a escolha do ambiente para o método, pode ser usada em todas as rotas
        If optionProduction.Checked Then
            url = "https://pix.tecnospeed.com.br/oauth2/token"
        Else
            url = "https://pix.tecnospeed.com.br/oauth2/token"
        End If

        Dim client = New RestClient(url)
        Dim request = New RestRequest()
        textoResposta.Text = ""

        request.AddHeader("cache-control", "no-cache")
        request.AddHeader("Content-Type", "application/json")
        request.AddHeader("Authorization", "Basic " & encodeBase64)
        request.AddBody(objCamposAutenticar, "application/x-www-form-urlencoded")


        Dim json = Await client.ExecutePostAsync(request)
        Dim jsonParse = JObject.Parse(json.Content)

        textoResposta.Text = JsonConvert.SerializeObject(jsonParse, Formatting.Indented)

        boxAcessTokenSh.Text = jsonParse.GetValue("access_token")

    End Sub

    Private Async Sub btnAutenticaCompany_Click(sender As Object, e As EventArgs) Handles btnAutenticaCompany.Click
        Dim url As String = ""
        Dim clientID As String = boxCompanyClientID.Text
        Dim clientSecret As String = boxCompanyClientSecret.Text
        Dim objCamposAutenticar = textoEntrada.Text
        Dim toBse64 As String = clientID & ":" & clientSecret
        Dim textoAsBytes As Byte() = Encoding.ASCII.GetBytes(toBse64)
        Dim encodeBase64 As String = System.Convert.ToBase64String(textoAsBytes)

        If optionProduction.Checked Then
            url = "https://pix.tecnospeed.com.br/oauth2/token"
        Else
            url = "https://pix.tecnospeed.com.br/oauth2/token"
        End If

        textoResposta.Text = ""

        'Define os dados
        Dim client = New RestClient(url)
        Dim request = New RestRequest()
        request.AddHeader("cache-control", "no-cache")
        request.AddHeader("Content-Type", "application/json")
        request.AddHeader("Authorization", "Basic " & encodeBase64)
        request.AddBody(objCamposAutenticar, "application/x-www-form-urlencoded")

        'Executa a requisicao
        Dim json = Await client.ExecutePostAsync(request)
        Dim jsonParse = JObject.Parse(json.Content)

        'Executa a leitura dos dados
        textoResposta.Text = JsonConvert.SerializeObject(jsonParse, Formatting.Indented)
        boxAcessTokenCompany.Text = jsonParse.GetValue("access_token")
    End Sub

    Private Async Sub btnCadastrarCompany_Click(sender As Object, e As EventArgs) Handles btnCadastrarCompany.Click
        Dim url As String = ""
        Dim objCamposCadastrar = textoEntrada.Text

        If optionProduction.Checked Then
            url = "https://pix.tecnospeed.com.br/api/v1/companies"
        Else
            url = "https://pix.tecnospeed.com.br/sandbox/companies"
        End If

        textoResposta.Text = ""

        Dim client = New RestClient(url)
        Dim request = New RestRequest()
        request.AddHeader("cache-control", "no-cache")
        request.AddHeader("Content-Type", "application/json")
        request.AddHeader("Authorization", "Bearer " & boxAcessTokenSh.Text)
        request.AddBody(objCamposCadastrar, "application/json")

        Dim json = Await client.ExecutePostAsync(request)
        Dim jsonParse = JObject.Parse(json.Content)

        textoResposta.Text = JsonConvert.SerializeObject(jsonParse, Formatting.Indented)
        boxIdCompany.Text = jsonParse.GetValue("id")
    End Sub

    Private Async Sub listaCompany_Click(sender As Object, e As EventArgs) Handles listaCompany.Click

        Dim url As String = ""
        Dim objCamposCadastrar = textoEntrada.Text

        If optionProduction.Checked Then
            url = "https://pix.tecnospeed.com.br/api/v1/companies"
        Else
            url = "https://pix.tecnospeed.com.br/sandbox/companies"
        End If

        textoResposta.Text = ""

        Dim client = New RestClient(url)
        Dim request = New RestRequest()

        request.AddHeader("cache-control", "no-cache")
        request.AddHeader("Content-Type", "application/json")
        request.AddHeader("Authorization", "Bearer " & boxAcessTokenSh.Text)
        request.AddBody(objCamposCadastrar, "application/json")

        Dim json = Await client.ExecutePostAsync(request)
        Dim jsonParse = JObject.Parse(json.Content)

        textoResposta.Text = JsonConvert.SerializeObject(jsonParse, Formatting.Indented)
        boxIdCompany.Text = jsonParse.GetValue("id")
    End Sub

    Private Async Sub atualizaCompany_Click(sender As Object, e As EventArgs) Handles AtualizarCompanyPut.Click
        Dim url As String = ""
        Dim objCamposCadastrar = textoEntrada.Text

        If optionProduction.Checked Then
            url = "https://pix.tecnospeed.com.br/api/v1/companies/" + edtcompanypatch.Text
        Else
            url = "https://pix.tecnospeed.com.br/sandbox/companies/" + edtcompanypatch.Text
        End If

        Dim client = New RestClient(url)
        Dim request = New RestRequest()

        textoResposta.Text = ""

        request.Method = Method.Patch
        request.AddHeader("cache-control", "no-cache")
        request.AddHeader("Content-Type", "application/json")
        request.AddHeader("Authorization", "Bearer " + boxAcessTokenSh.Text)
        request.AddBody(objCamposCadastrar, "application/json")

        Dim json = Await client.ExecuteAsync(request)
        Dim jsonParse = JObject.Parse(json.Content)

        textoResposta.Text = JsonConvert.SerializeObject(jsonParse, Formatting.Indented)

        boxIdCompany.Text = jsonParse.GetValue("id")

    End Sub

    Private Async Sub desativaCompany(sender As Object, e As EventArgs) Handles button6.Click

        Dim url As String = ""
        Dim objCamposCadastrar = textoEntrada.Text

        If optionProduction.Checked Then
            url = "https://pix.tecnospeed.com.br/api/v1/companies/" & textoEntrada.Text
        Else
            url = "https://pix.tecnospeed.com.br/sandbox/companies/" & textoEntrada.Text
        End If

        Dim client = New RestClient(url)
        Dim request = New RestRequest()
        textoResposta.Text = ""

        request.AddHeader("cache-control", "no-cache")
        request.AddHeader("Content-Type", "application/json")
        request.AddHeader("Authorization", "Bearer " & boxAcessTokenSh.Text)
        request.AddBody(objCamposCadastrar, "application/json")

        Dim json = Await client.ExecutePutAsync(request)
        Dim jsonParse = JObject.Parse(json.Content)


        textoResposta.Text = JsonConvert.SerializeObject(jsonParse, Formatting.Indented)
        boxIdCompany.Text = jsonParse.GetValue("id")

    End Sub


    Private Async Sub btnCadConta_Click(sender As Object, e As EventArgs) Handles btnCadConta.Click

        Dim url As String = ""
        Dim objCamposCadastrar = textoEntrada.Text

        If optionProduction.Checked Then
            url = "https://pix.tecnospeed.com.br/api/v1/accounts" & edtaccountpatch.Text
        Else
            url = "https://pix.tecnospeed.com.br/sandbox/accounts" & edtaccountput.Text
        End If

        Dim client = New RestClient(url)
        Dim request = New RestRequest()

        textoResposta.Text = ""

        request.AddHeader("cache-control", "no-cache")
        request.AddHeader("Content-Type", "application/json")
        request.AddHeader("Authorization", "Bearer " & boxAcessTokenCompany.Text)
        request.AddBody(objCamposCadastrar, "application/json")


        Dim json = Await client.ExecutePostAsync(request)
        Dim jsonParse = JObject.Parse(json.Content)

        textoResposta.Text = JsonConvert.SerializeObject(jsonParse, Formatting.Indented)
        boxIdCompany.Text = jsonParse.GetValue("id")

    End Sub

    Private Async Sub alteraContaPatch(sender As Object, e As EventArgs) Handles button9.Click

        Dim url As String = ""
        Dim objCamposCadastrar = textoEntrada.Text

        If optionProduction.Checked Then
            url = "https://pix.tecnospeed.com.br/api/v1/accounts/" + edtaccountpatch.Text
        Else
            url = "https://pix.tecnospeed.com.br/sandbox/accounts/" + edtaccountpatch.Text
        End If

        Dim client = New RestClient(url)
        Dim request = New RestRequest()

        textoResposta.Text = ""

        request.Method = Method.Patch
        request.AddHeader("cache-control", "no-cache")
        request.AddHeader("Content-Type", "application/json")
        request.AddHeader("Authorization", "Bearer " & boxAcessTokenCompany.Text)
        request.AddBody(objCamposCadastrar, "application/json")


        Dim json = Await client.ExecuteAsync(request)
        Dim jsonParse = JObject.Parse(json.Content)

        textoResposta.Text = JsonConvert.SerializeObject(jsonParse, Formatting.Indented)
        boxIdCompany.Text = jsonParse.GetValue("id")

    End Sub

    Private Async Sub button8_Click(sender As Object, e As EventArgs) Handles button8.Click

        Dim url As String = ""
        Dim objCamposCadastrar = textoEntrada.Text

        If optionProduction.Checked Then
            url = "https://pix.tecnospeed.com.br/api/v1/accounts"
        Else
            url = "https://pix.tecnospeed.com.br/sandbox/accounts"
        End If

        Dim client = New RestClient(url)
        Dim request = New RestRequest()
        textoResposta.Text = ""

        request.AddHeader("cache-control", "no-cache")
        request.AddHeader("Content-Type", "application/json")
        request.AddHeader("Authorization", "Bearer " & boxAcessTokenCompany.Text)
        request.AddBody(objCamposCadastrar, "application/json")


        Dim json = Await client.ExecuteGetAsync(request)
        Dim jsonParse = JObject.Parse(json.Content)

        textoResposta.Text = JsonConvert.SerializeObject(jsonParse, Formatting.Indented)
        boxIdCompany.Text = jsonParse.GetValue("id")

    End Sub

    Private Async Sub desativaConta(sender As Object, e As EventArgs) Handles button13.Click

        Dim url As String = ""
        Dim objCamposCadastrar = textoEntrada.Text

        If optionProduction.Checked Then
            url = "https://pix.tecnospeed.com.br/api/v1/accounts/"
        Else
            url = "https://pix.tecnospeed.com.br/sandbox/accounts/"
        End If

        Dim client = New RestClient(url)
        Dim request = New RestRequest()

        request.Method = Method.Delete
        textoResposta.Text = ""
        request.AddHeader("cache-control", "no-cache")
        ' request.AddHeader("Content-Type", "application/json")
        request.AddHeader("Authorization", "Bearer " & boxAcessTokenCompany.Text)
        request.AddParameter("id", "e11b36d4-9732-4ce9-83d4-dd295d9d3383")

        Dim json = Await client.ExecuteAsync(request)
        If json.StatusCode = 204 Then
            textoResposta.Text = "Account excluida"
        Else
            textoResposta.Text = json.ErrorMessage
        End If


    End Sub

    Private Sub tabPage3_Click(sender As Object, e As EventArgs) Handles tabPage3.Click

    End Sub

    Private Async Sub btnEmitirPix_Click(sender As Object, e As EventArgs) Handles btnEmitirPix.Click

        Dim url As String = ""
        Dim objCamposPix = textoEntrada.Text

        If optionProduction.Checked Then
            url = "https://pix.tecnospeed.com.br/api/v1/pix/dynamic"
        Else
            url = " https://pix.tecnospeed.com.br/sandbox/pix/dynamic"
        End If

        Dim client = New RestClient(url)
        Dim request = New RestRequest()
        textoResposta.Text = ""

        request.AddHeader("cache-control", "no-cache")
        request.AddHeader("Content-Type", "application/json")
        request.AddHeader("Authorization", "Bearer " & boxAcessTokenCompany.Text)
        request.AddBody(objCamposPix, "application/json")

        Dim json = Await client.ExecutePostAsync(request)
        Dim jsonParse = JObject.Parse(json.Content)

        textoResposta.Text = JsonConvert.SerializeObject(jsonParse, Formatting.Indented)
        boxIdPix.Text = jsonParse.GetValue("id")

    End Sub

    Private Async Sub btnConsultPix_Click(sender As Object, e As EventArgs) Handles btnConsultPix.Click

        Dim url As String = ""
        Dim objCamposPix = textoEntrada.Text

        If optionProduction.Checked Then
            url = "https://pix.tecnospeed.com.br/api/v1/pix/" + boxIdPix.Text
        Else
            url = "https://pix.tecnospeed.com.br/sandbox/pix/" + boxIdPix.Text
        End If

        Dim client = New RestClient(url)
        Dim request = New RestRequest()
        textoResposta.Text = ""

        request.AddHeader("cache-control", "no-cache")
        request.AddHeader("Content-Type", "application/json")
        request.AddHeader("Authorization", "Bearer " & boxAcessTokenCompany.Text)


        Dim json = Await client.ExecuteGetAsync(request)
        Dim jsonParse = JObject.Parse(json.Content)

        textoResposta.Text = JsonConvert.SerializeObject(jsonParse, Formatting.Indented)
        boxUrlQrCode.Text = jsonParse.GetValue("URLQrCode")

    End Sub

    Private Sub btnQrCode_Click(sender As Object, e As EventArgs) Handles btnQrCode.Click

    End Sub

    Private Async Sub button18_Click(sender As Object, e As EventArgs)

        Dim url As String = ""
        Dim objCamposPix = textoEntrada.Text

        If optionProduction.Checked Then
            url = "https://pix.tecnospeed.com.br/api/v1/pix/" & textoEntrada.Text
        Else
            url = "https://pix.tecnospeed.com.br/sandbox/pix/" & textoEntrada.Text
        End If

        Dim client = New RestClient(url & boxIdPix.Text)
        Dim request = New RestRequest()
        textoResposta.Text = ""

        request.AddHeader("cache-control", "no-cache")
        request.AddHeader("Content-Type", "application/json")
        request.AddHeader("Authorization", "Bearer " & boxAcessTokenCompany.Text)


        Dim json = Await client.ExecuteGetAsync(request)
        Dim jsonParse = JObject.Parse(json.Content)

        textoResposta.Text = JsonConvert.SerializeObject(jsonParse, Formatting.Indented)
        boxUrlQrCode.Text = jsonParse.GetValue("URLQrCode")
    End Sub

    Private Async Sub button17_Click(sender As Object, e As EventArgs)

        Dim url As String = ""
        Dim objCamposPix = textoEntrada.Text

        If optionProduction.Checked Then
            url = "https://pix.tecnospeed.com.br/api/v1/pix/charge/" & textoEntrada.Text
        Else
            url = "https://pix.tecnospeed.com.br/sandbox/pix/charge/" & textoEntrada.Text
        End If

        Dim client = New RestClient(url & boxIdPix.Text)
        Dim request = New RestRequest()
        textoResposta.Text = ""

        request.AddHeader("cache-control", "no-cache")
        request.AddHeader("Content-Type", "application/json")
        request.AddHeader("Authorization", "Bearer " & boxAcessTokenCompany.Text)


        Dim json = Await client.ExecuteGetAsync(request)
        Dim jsonParse = JObject.Parse(json.Content)

        textoResposta.Text = JsonConvert.SerializeObject(jsonParse, Formatting.Indented)
        boxUrlQrCode.Text = jsonParse.GetValue("URLQrCode")
    End Sub
    Private Sub BackgroundWorker1_DoWork(sender As Object, e As System.ComponentModel.DoWorkEventArgs)

    End Sub

    Private Async Sub btntrocarcertificado_Click(sender As Object, e As EventArgs) Handles btntrocarcertificado.Click
        If String.IsNullOrEmpty(txtCertificado.Text) Then

            MessageBox.Show("Primeiro, selecione o certificado")

            Return

        End If


        textoResposta.Text = ""
        Dim ObjCamposConta = New With {Key .description = "Certificado de teste", Key .password = txtSenhaCertificado.Text, Key .extension = txtExtension.Text, Key .accountId = txtAccountId.Text, Key .file = File.ReadAllBytes(txtCertificado.Text)}
        Dim js As JavaScriptSerializer = New JavaScriptSerializer()
        js.Serialize(ObjCamposConta)
        textoEntrada.Text = JsonConvert.SerializeObject(ObjCamposConta, Formatting.Indented)



        Dim url As String = ""
        Dim email As String = boxShEmail.Text
        Dim password As String = boxShSenha.Text
        Dim uploadCertificado = textoEntrada.Text

        If optionProduction.Checked Then
            url = "https://pix.tecnospeed.com.br/api/v1/certificate/" + txtAccountId.Text
        Else
            url = "https://pix.tecnospeed.com.br/sandbox/certificate/" + txtAccountId.Text
        End If

        Dim client = New RestClient(url)
        Dim request = New RestRequest()
        textoResposta.Text = ""

        request.AddHeader("cache-control", "no-cache")
        request.AddHeader("Content-Type", "application/json")
        request.AddHeader("Authorization", "Bearer " & boxAcessTokenCompany.Text)
        request.AddBody(uploadCertificado, "multipart/form-data")
        'request.AddFile("file", txtCertificado.Text)
        'request.AddParameter("file", File.ReadAllBytes(txtCertificado.Text), ParameterType.RequestBody)






        Dim json = Await client.ExecutePutAsync(request)
        Dim jsonParse = JObject.Parse(json.Content)

        textoResposta.Text = JsonConvert.SerializeObject(jsonParse, Formatting.Indented)

        boxAcessTokenSh.Text = jsonParse.GetValue("access_token")

    End Sub



    Private Async Sub btnlistarcertificados_Click(sender As Object, e As EventArgs) Handles btnlistarcertificados.Click
        Dim url As String = ""
        Dim objCamposCadastrar = textoEntrada.Text

        If optionProduction.Checked Then
            url = "https://pix.tecnospeed.com.br/api/v1/certificate"
        Else
            url = "https://pix.tecnospeed.com.br/sandbox/certificate"
        End If

        Dim client = New RestClient(url)
        Dim request = New RestRequest()
        textoResposta.Text = ""

        request.AddHeader("cache-control", "no-cache")
        request.AddHeader("Content-Type", "application/json")
        request.AddHeader("Authorization", "Bearer " & boxAcessTokenCompany.Text)
        request.AddBody(objCamposCadastrar, "application/json")


        Dim json = Await client.ExecuteGetAsync(request)
        Dim jsonParse = JObject.Parse(json.Content)

        textoResposta.Text = JsonConvert.SerializeObject(jsonParse, Formatting.Indented)
        boxIdCompany.Text = jsonParse.GetValue("id")
    End Sub

    Private Sub btnSelecionarCertificado_Click(sender As Object, e As EventArgs) Handles btnSelecionarCertificado.Click

        If openCertificado.ShowDialog() = DialogResult.OK Then
            txtCertificado.Text = openCertificado.FileName
            txtExtension.Text = Path.GetExtension(openCertificado.FileName).Replace(".", "")

        End If


    End Sub

    Private Sub openCertificado_FileOk(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles openCertificado.FileOk

    End Sub




    Private Async Sub btnuploadcertificado_Click(sender As Object, e As EventArgs) Handles btnuploadcertificado.Click

        If String.IsNullOrEmpty(txtCertificado.Text) Then

            MessageBox.Show("Primeiro, selecione o certificado")

            Return

        End If


        textoResposta.Text = ""
        Dim ObjCamposConta = New With {Key .description = "Certificado de teste", Key .password = txtSenhaCertificado.Text, Key .extension = txtExtension.Text, Key .accountId = txtAccountId.Text, Key .file = File.ReadAllBytes(txtCertificado.Text)}
        Dim js As JavaScriptSerializer = New JavaScriptSerializer()
        js.Serialize(ObjCamposConta)
        textoEntrada.Text = JsonConvert.SerializeObject(ObjCamposConta, Formatting.Indented)



        Dim url As String = ""
        Dim email As String = boxShEmail.Text
        Dim password As String = boxShSenha.Text
        Dim uploadCertificado = textoEntrada.Text

        If optionProduction.Checked Then
            url = "https://pix.tecnospeed.com.br/api/v1/certificate/upload"
        Else
            url = "https://pix.tecnospeed.com.br/sandbox/certificate/upload"
        End If

        Dim client = New RestClient(url)
        Dim request = New RestRequest()
        textoResposta.Text = ""

        request.AddHeader("cache-control", "no-cache")
        request.AddHeader("Content-Type", "application/json")
        request.AddHeader("Authorization", "Bearer " & boxAcessTokenCompany.Text)
        request.AddBody(uploadCertificado, "multipart/form-data")
        'request.AddFile("file", txtCertificado.Text)
        'request.AddParameter("file", File.ReadAllBytes(txtCertificado.Text), ParameterType.RequestBody)






        Dim json = Await client.ExecutePostAsync(request)
        Dim jsonParse = JObject.Parse(json.Content)

        textoResposta.Text = JsonConvert.SerializeObject(jsonParse, Formatting.Indented)

        boxAcessTokenSh.Text = jsonParse.GetValue("access_token")


    End Sub
    Public Function objuser() As Object

        Return New With {Key .name = 10.95, Key .email = "Teste", Key .description = "01001001000113"}

    End Function
    Private Async Sub Button22_Click(sender As Object, e As EventArgs)

        Dim url As String = ""
        Dim objCamposCadastrar = textoEntrada.Text

        If optionProduction.Checked Then
            url = "https://pix.tecnospeed.com.br/api/v1/users"
        Else
            url = "https://pix.tecnospeed.com.br/sandbox/users"
        End If

        Dim client = New RestClient(url)
        Dim request = New RestRequest()
        textoResposta.Text = ""

        request.AddHeader("cache-control", "no-cache")
        request.AddHeader("Content-Type", "application/json")
        request.AddHeader("Authorization", "Bearer " & boxAcessTokenCompany.Text)
        request.AddBody(objCamposCadastrar, "application/json")


        Dim json = Await client.ExecuteGetAsync(request)
        Dim jsonParse = JObject.Parse(json.Content)

        textoResposta.Text = JsonConvert.SerializeObject(jsonParse, Formatting.Indented)
        boxIdCompany.Text = jsonParse.GetValue("id")
    End Sub

    Public Function objwebhook() As Object

        Return New With {Key .onEvents = "PIX_SUCCESSFUL", Key .method = "POST", Key .url = "http://minhaapi.com/callback", Key .headers = "", .ContentType = "application/json", Key .Authorization = "Basic bWV1IHNlZ3JlZG8="}
    End Function

    Private Sub Label26_Click(sender As Object, e As EventArgs) Handles Label26.Click

    End Sub

    Private Sub senha_Click(sender As Object, e As EventArgs) Handles senha.Click

    End Sub

    Private Sub Label24_Click(sender As Object, e As EventArgs) Handles Label24.Click

    End Sub
End Class
