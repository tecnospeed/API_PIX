﻿Imports System.IO
Imports System.Text
Imports Nancy.Json
Imports Newtonsoft.Json
Imports Newtonsoft.Json.Linq
Imports RestSharp

Public Class Form1


    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Public Function autenticaSH() As Object
        Return New With {Key .grant_type = "client_credentials", Key .role = "software_house"}
    End Function

    Public Function obCamposCompany() As Object
        Return New With {
            Key .zipcode = "86010390", Key .name = "Teste", Key .email = "inga@teste.com.br", Key .cpfCnpj = "01001001000113", Key .city = "Maringá", Key .state = "PR"
                        }
    End Function

    Public Function autenticaCompany() As Object
        Return New With {
            Key .grant_type = "client_credentials", Key .role = "company"
                        }
    End Function

    Public Function obCamposConta() As Object
        Return New With {Key .bankAccount = "12354", Key .bankAccountType = "SAVINGS", Key .bankAgency = "0201", Key .bankCode = "001", Key .clientId = "a477ed3c-0000-111-2222-52bcd6309131", Key .clientSecret = "9dc84cc8-2222-0000-5555-4378489340e7", Key .pixKey = "(99)999999999"
    }
    End Function


    Public Function obCamposPix() As Object
        Return New With {Key .accountId = boxIdConta.Text, Key .payerCpfCnpj = "01001001000113", Key .payerName = "payer Teste", Key .amount = 1.0
    }
    End Function

    Public Function obCamposPixCobranca() As Object
        Return New With {Key .accountId = "", Key .description = "01001001000113", Key .tags = "", Key .calendar = "", Key .payer = "{", Key .cpfCnpj = "14134409837", Key .name = "MARCOS ANTONIO BOLONHA", Key .email = "marcos@softconinformatica.com.br", Key .street = "RUA TAMOIOS 500", Key .city = "Lençóis Paulista", Key .state = "SP", Key .zipcode = "18682343" & "}"
    }
    End Function
    Private Sub BtnExemploSh_Click(sender As Object, e As EventArgs) Handles btnExemploSh.Click


        textoResposta.Text = ""
        Dim objCamposSH = autenticaSH()
        Dim js As JavaScriptSerializer = New JavaScriptSerializer()
        js.Serialize(objCamposSH)
        textoEntrada.Text = JsonConvert.SerializeObject(objCamposSH, Formatting.Indented)

    End Sub
    Private Sub btnOrientacaoAutenticar_Click(sender As Object, e As EventArgs) Handles btnOrientacaoAutenticar.Click

        textoOrientacao.Text = vbLf & " " & "Selecione o ambiente desejado " & vbLf & vbLf & "Realize a autenticação da Softwarehouse. " & vbLf & " " & "- Será necessário ter um cadastro em 'conta.tecnospeed.com.br' " & vbLf & "- Com os dados de cadastros em mãos, informe o E-mail e senha " & vbLf & "- Primeiro selecione o boão exemplo, em seguida Software house " & vbLf & vbLf & "- Como resposta da API, será disponibilizado um acess_token no campo 'Acess_token' " & vbLf & "- Com o token em mãos, seguiremos para a aba 'Company', pois com a softwarehouse autenticada, conseguimos cadastrar as companys que irão emitir os pix. " & vbLf & vbLf & vbLf & vbLf & "Autenticar a company. " & vbLf & "- Com os dados de cadastros em mãos, informe o ClientId e ClientSecret disponibilizados via e-mail" & vbLf & "- Primeiro selecione o boão exemplo, em seguida Company " & vbLf & "- Como resposta da API, será disponibilizado um acess_token no campo 'Acess_token' " & vbLf & "- Com o token em mãos, seguiremos para a aba 'Conta', pois com a company autenticada, conseguimos cadastrar contas, emitir pix..."

    End Sub

    Private Sub btnAutenticaExemploCompany_Click(sender As Object, e As EventArgs) Handles btnAutenticaExemploCompany.Click
        textoResposta.Text = ""
        Dim objCamposCompany = autenticaCompany()
        Dim js As JavaScriptSerializer = New JavaScriptSerializer()
        js.Serialize(objCamposCompany)
        textoEntrada.Text = JsonConvert.SerializeObject(objCamposCompany, Formatting.Indented)

    End Sub

    Private Sub btnExemploCompany_Click(sender As Object, e As EventArgs) Handles btnExemploCompany.Click
        textoResposta.Text = ""
        Dim ObjCamposCompany = obCamposCompany()
        Dim js As JavaScriptSerializer = New JavaScriptSerializer()
        js.Serialize(ObjCamposCompany)
        textoEntrada.Text = JsonConvert.SerializeObject(ObjCamposCompany, Formatting.Indented)
    End Sub

    Private Sub button4_Click(sender As Object, e As EventArgs) Handles button4.Click
        textoResposta.Text = ""
        Dim ObjCamposCompany = obCamposCompany()
        Dim js As JavaScriptSerializer = New JavaScriptSerializer()
        js.Serialize(ObjCamposCompany)
        textoEntrada.Text = JsonConvert.SerializeObject(ObjCamposCompany, Formatting.Indented)
    End Sub

    Private Sub button5_Click(sender As Object, e As EventArgs) Handles button5.Click
        textoResposta.Text = ""
        Dim ObjCamposCompany = obCamposCompany()
        Dim js As JavaScriptSerializer = New JavaScriptSerializer()
        js.Serialize(ObjCamposCompany)
        textoEntrada.Text = JsonConvert.SerializeObject(ObjCamposCompany, Formatting.Indented)
    End Sub

    Private Sub button7_Click(sender As Object, e As EventArgs) Handles button7.Click

    End Sub

    Private Sub btnOrientacaoCompany_Click(sender As Object, e As EventArgs) Handles btnOrientacaoCompany.Click
        textoOrientacao.Text = vbLf & " " & "Realizando o cadastro de um company." & vbLf & "- Selecione o botão 'exemplo', para ser exibido um JSON " & vbLf & "- Após editar o JSON informado, selecione o botão 'Cadastrar' " & vbLf & "- Como resposta da API, será retornado um ID de identificação da company. " & vbLf & vbLf & "- Após cadastrado, será enviado um e-mail para o endereço informado no momento do cadastro. " & vbLf & "- Ao receber, retorne para a aba Autenticar."
    End Sub

    Private Sub tabPage2_Click(sender As Object, e As EventArgs) Handles tabPage2.Click

    End Sub

    Private Sub btnExemploConta_Click(sender As Object, e As EventArgs) Handles btnExemploConta.Click
        textoResposta.Text = ""
        Dim ObjCamposConta = obCamposConta()
        Dim js As JavaScriptSerializer = New JavaScriptSerializer()
        js.Serialize(ObjCamposConta)
        textoEntrada.Text = JsonConvert.SerializeObject(ObjCamposConta, Formatting.Indented)
    End Sub

    Private Sub button10_Click(sender As Object, e As EventArgs) Handles button10.Click

        textoResposta.Text = ""
        Dim ObjCamposConta = obCamposConta()
        Dim js As JavaScriptSerializer = New JavaScriptSerializer()
        js.Serialize(ObjCamposConta)
        textoEntrada.Text = JsonConvert.SerializeObject(ObjCamposConta, Formatting.Indented)

    End Sub

    Private Sub button12_Click(sender As Object, e As EventArgs) Handles button12.Click

        textoResposta.Text = ""
        Dim ObjCamposConta = obCamposConta()
        Dim js As JavaScriptSerializer = New JavaScriptSerializer()
        js.Serialize(ObjCamposConta)
        textoEntrada.Text = JsonConvert.SerializeObject(ObjCamposConta, Formatting.Indented)

    End Sub

    Private Sub btnExemploPix_Click(sender As Object, e As EventArgs) Handles btnExemploPix.Click

        textoResposta.Text = ""
        Dim ObjCamposPix = obCamposPix()
        Dim js As JavaScriptSerializer = New JavaScriptSerializer()
        js.Serialize(ObjCamposPix)
        textoEntrada.Text = JsonConvert.SerializeObject(ObjCamposPix, Formatting.Indented)

    End Sub

    Private Async Sub btnAutenticaSh_Click(sender As Object, e As EventArgs) Handles btnAutenticaSh.Click

        Dim url As String = ""
        Dim email As String = boxShEmail.Text
        Dim password As String = boxShSenha.Text
        Dim objCamposAutenticar = textoEntrada.Text
        Dim toBse64 As String = email & ":" & password
        Dim textoAsBytes As Byte() = System.Text.Encoding.ASCII.GetBytes(toBse64)
        Dim encodeBase64 As String = System.Convert.ToBase64String(textoAsBytes)

        If optionProduction.Checked Then
            url = "https://pix.tecnospeed.com.br/oauth2/token"
        Else
            url = "https://pix.tecnospeed.com.br/oauth2/token"
        End If

        Dim client = New RestClient(url)
        Dim request = New RestRequest()
        textoResposta.Text = ""

        request.AddHeader("cache-control", "no-cache")
        request.AddHeader("Content-Type", "application/json")
        request.AddHeader("Authorization", "Basic " & encodeBase64)
        request.AddBody(objCamposAutenticar, "application/x-www-form-urlencoded")


        Dim json = Await client.ExecutePostAsync(request)
        Dim jsonParse = JObject.Parse(json.Content)

        textoResposta.Text = JsonConvert.SerializeObject(jsonParse, Formatting.Indented)

        boxAcessTokenSh.Text = jsonParse.GetValue("access_token")

    End Sub

    Private Async Sub btnAutenticaCompany_Click(sender As Object, e As EventArgs) Handles btnAutenticaCompany.Click
        Dim url As String = ""
        Dim clientID As String = boxCompanyClientID.Text
        Dim clientSecret As String = boxCompanyClientSecret.Text
        Dim objCamposAutenticar = textoEntrada.Text
        Dim toBse64 As String = clientID & ":" & clientSecret
        Dim textoAsBytes As Byte() = Encoding.ASCII.GetBytes(toBse64)
        Dim encodeBase64 As String = System.Convert.ToBase64String(textoAsBytes)

        If optionProduction.Checked Then
            url = "https://pix.tecnospeed.com.br/oauth2/token"
        Else
            url = "https://pix.tecnospeed.com.br/oauth2/token"
        End If

        textoResposta.Text = ""

        'monta a requisicao
        Dim client = New RestClient(url)
        Dim request = New RestRequest()
        request.AddHeader("cache-control", "no-cache")
        request.AddHeader("Content-Type", "application/json")
        request.AddHeader("Authorization", "Basic " & encodeBase64)
        request.AddBody(objCamposAutenticar, "application/x-www-form-urlencoded")

        'executa a requisicao
        Dim json = Await client.ExecutePostAsync(request)
        Dim jsonParse = JObject.Parse(json.Content)

        'faz a leitura dos dados
        textoResposta.Text = JsonConvert.SerializeObject(jsonParse, Formatting.Indented)
        boxAcessTokenCompany.Text = jsonParse.GetValue("access_token")
    End Sub

    Private Async Sub btnCadastrarCompany_Click(sender As Object, e As EventArgs) Handles btnCadastrarCompany.Click
        Dim url As String = ""
        Dim objCamposCadastrar = textoEntrada.Text

        If optionProduction.Checked Then
            url = "https://pix.tecnospeed.com.br/api/v1/companies"
        Else
            url = "https://pix.tecnospeed.com.br/sandbox/companies"
        End If

        textoResposta.Text = ""

        Dim client = New RestClient(url)
        Dim request = New RestRequest()
        request.AddHeader("cache-control", "no-cache")
        request.AddHeader("Content-Type", "application/json")
        request.AddHeader("Authorization", "Bearer " & boxAcessTokenSh.Text)
        request.AddBody(objCamposCadastrar, "application/json")

        Dim json = Await client.ExecutePostAsync(request)
        Dim jsonParse = JObject.Parse(json.Content)

        textoResposta.Text = JsonConvert.SerializeObject(jsonParse, Formatting.Indented)
        boxIdCompany.Text = jsonParse.GetValue("id")
    End Sub

    Private Async Sub button1_Click(sender As Object, e As EventArgs) Handles button1.Click

        Dim url As String = ""
        Dim objCamposCadastrar = textoEntrada.Text

        If optionProduction.Checked Then
            url = "https://pix.tecnospeed.com.br/api/v1/companies"
        Else
            url = "https://pix.tecnospeed.com.br/sandbox/companies"
        End If

        textoResposta.Text = ""

        Dim client = New RestClient(url)
        Dim request = New RestRequest()

        request.AddHeader("cache-control", "no-cache")
        request.AddHeader("Content-Type", "application/json")
        request.AddHeader("Authorization", "Bearer " & boxAcessTokenSh.Text)
        request.AddBody(objCamposCadastrar, "application/json")

        Dim json = Await client.ExecutePostAsync(request)
        Dim jsonParse = JObject.Parse(json.Content)

        textoResposta.Text = JsonConvert.SerializeObject(jsonParse, Formatting.Indented)
        boxIdCompany.Text = jsonParse.GetValue("id")
    End Sub

    Private Async Sub button3_Click(sender As Object, e As EventArgs) Handles AtualizarCompanyPut.Click
        Dim url As String = ""
        Dim objCamposCadastrar = textoEntrada.Text

        If optionProduction.Checked Then
            url = "https://pix.tecnospeed.com.br/api/v1/companies/" + edtcompanypatch.Text
        Else
            url = "https://pix.tecnospeed.com.br/sandbox/companies/" + edtcompanypatch.Text
        End If

        Dim client = New RestClient(url)
        Dim request = New RestRequest()

        textoResposta.Text = ""

        request.Method = Method.Patch
        request.AddHeader("cache-control", "no-cache")
        request.AddHeader("Content-Type", "application/json")
        request.AddHeader("Authorization", "Bearer " + boxAcessTokenSh.Text)
        request.AddBody(objCamposCadastrar, "application/json")

        Dim json = Await client.ExecuteAsync(request)
        Dim jsonParse = JObject.Parse(json.Content)

        textoResposta.Text = JsonConvert.SerializeObject(jsonParse, Formatting.Indented)

        boxIdCompany.Text = jsonParse.GetValue("id")

    End Sub

    Private Async Sub button2_Click(sender As Object, e As EventArgs) Handles button2.Click
        Dim url As String = ""
        Dim objCamposCadastrar = textoEntrada.Text

        If optionProduction.Checked Then
            url = "https://pix.tecnospeed.com.br/api/v1/companies/" + edtcompanypatch.Text
        Else
            url = "https://pix.tecnospeed.com.br/sandbox/companies/" + edtcompanypatch.Text
        End If

        Dim client = New RestClient(url)
        Dim request = New RestRequest()
        textoResposta.Text = ""

        request.AddHeader("cache-control", "no-cache")
        request.AddHeader("Content-Type", "application/json")
        request.AddHeader("Authorization", "Bearer " & boxAcessTokenSh.Text)
        request.AddBody(objCamposCadastrar, "application/json")

        Dim json = Await client.ExecutePutAsync(request)
        Dim jsonParse = JObject.Parse(json.Content)

        textoResposta.Text = JsonConvert.SerializeObject(jsonParse, Formatting.Indented)
        boxIdCompany.Text = jsonParse.GetValue("id")

    End Sub

    Private Async Sub button6_Click(sender As Object, e As EventArgs) Handles button6.Click

        Dim url As String = ""
        Dim objCamposCadastrar = textoEntrada.Text

        If optionProduction.Checked Then
            url = "https://pix.tecnospeed.com.br/api/v1/companies/" & textoEntrada.Text
        Else
            url = "https://pix.tecnospeed.com.br/sandbox/companies/" & textoEntrada.Text
        End If

        Dim client = New RestClient(url)
        Dim request = New RestRequest()
        textoResposta.Text = ""

        request.AddHeader("cache-control", "no-cache")
        request.AddHeader("Content-Type", "application/json")
        request.AddHeader("Authorization", "Bearer " & boxAcessTokenSh.Text)
        request.AddBody(objCamposCadastrar, "application/json")

        Dim json = Await client.ExecutePutAsync(request)
        Dim jsonParse = JObject.Parse(json.Content)


        textoResposta.Text = JsonConvert.SerializeObject(jsonParse, Formatting.Indented)
        boxIdCompany.Text = jsonParse.GetValue("id")

    End Sub

    Private Sub btnOrientacaoConta_Click(sender As Object, e As EventArgs) Handles btnOrientacaoConta.Click

        textoOrientacao.Text = vbLf & " " & "Realizando o cadastro de uma conta." & vbLf & "- Selecione o botão 'exemplo', para ser exibido um JSON " & vbLf & "- Após editar o JSON informado, selecione o botão 'Cadastrar' " & vbLf & "- Como resposta da API, será retornado um ID de identificação da conta ( precisamos deste ID para emitirmos um PIX ). " & vbLf & "- Em seguida siga para a aba 'Emitir PIX'"

    End Sub

    Private Async Sub btnCadConta_Click(sender As Object, e As EventArgs) Handles btnCadConta.Click

        Dim url As String = ""
        Dim objCamposCadastrar = textoEntrada.Text

        If optionProduction.Checked Then
            url = "https://pix.tecnospeed.com.br/api/v1/accounts" & edtaccountpatch.Text
        Else
            url = "https://pix.tecnospeed.com.br/sandbox/accounts" & edtaccountput.Text
        End If

        Dim client = New RestClient(url)
        Dim request = New RestRequest()

        textoResposta.Text = ""

        request.AddHeader("cache-control", "no-cache")
        request.AddHeader("Content-Type", "application/json")
        request.AddHeader("Authorization", "Bearer " & boxAcessTokenCompany.Text)
        request.AddBody(objCamposCadastrar, "application/json")


        Dim json = Await client.ExecutePostAsync(request)
        Dim jsonParse = JObject.Parse(json.Content)

        textoResposta.Text = JsonConvert.SerializeObject(jsonParse, Formatting.Indented)
        boxIdCompany.Text = jsonParse.GetValue("id")

    End Sub

    Private Async Sub button9_Click(sender As Object, e As EventArgs) Handles button9.Click

        Dim url As String = ""
        Dim objCamposCadastrar = textoEntrada.Text

        If optionProduction.Checked Then
            url = "https://pix.tecnospeed.com.br/api/v1/accounts/" + edtaccountpatch.Text
        Else
            url = "https://pix.tecnospeed.com.br/sandbox/accounts/" + edtaccountpatch.Text
        End If

        Dim client = New RestClient(url)
        Dim request = New RestRequest()

        textoResposta.Text = ""

        request.Method = Method.Patch
        request.AddHeader("cache-control", "no-cache")
        request.AddHeader("Content-Type", "application/json")
        request.AddHeader("Authorization", "Bearer " & boxAcessTokenCompany.Text)
        request.AddBody(objCamposCadastrar, "application/json")


        Dim json = Await client.ExecuteAsync(request)
        Dim jsonParse = JObject.Parse(json.Content)

        textoResposta.Text = JsonConvert.SerializeObject(jsonParse, Formatting.Indented)
        boxIdCompany.Text = jsonParse.GetValue("id")

    End Sub

    Private Async Sub button8_Click(sender As Object, e As EventArgs) Handles button8.Click

        Dim url As String = ""
        Dim objCamposCadastrar = textoEntrada.Text

        If optionProduction.Checked Then
            url = "https://pix.tecnospeed.com.br/api/v1/accounts"
        Else
            url = "https://pix.tecnospeed.com.br/sandbox/accounts"
        End If

        Dim client = New RestClient(url)
        Dim request = New RestRequest()
        textoResposta.Text = ""

        request.AddHeader("cache-control", "no-cache")
        request.AddHeader("Content-Type", "application/json")
        request.AddHeader("Authorization", "Bearer " & boxAcessTokenCompany.Text)
        request.AddBody(objCamposCadastrar, "application/json")


        Dim json = Await client.ExecuteGetAsync(request)
        Dim jsonParse = JObject.Parse(json.Content)

        textoResposta.Text = JsonConvert.SerializeObject(jsonParse, Formatting.Indented)
        boxIdCompany.Text = jsonParse.GetValue("id")

    End Sub

    Private Async Sub button11_Click(sender As Object, e As EventArgs) Handles button11.Click

        Dim url As String = ""
        Dim objCamposCadastrar = textoEntrada.Text

        If optionProduction.Checked Then
            url = "https://pix.tecnospeed.com.br/api/v1/accounts/" + edtaccountput.Text
        Else
            url = "https://pix.tecnospeed.com.br/sandbox/accounts/" + edtaccountput.Text
        End If

        Dim client = New RestClient(url)
        Dim request = New RestRequest()
        textoResposta.Text = ""

        request.AddHeader("cache-control", "no-cache")
        request.AddHeader("Content-Type", "application/json")
        request.AddHeader("Authorization", "Bearer " & boxAcessTokenCompany.Text)
        request.AddBody(objCamposCadastrar, "application/json")


        Dim json = Await client.ExecutePutAsync(request)
        Dim jsonParse = JObject.Parse(json.Content)

        textoResposta.Text = JsonConvert.SerializeObject(jsonParse, Formatting.Indented)
        boxIdCompany.Text = jsonParse.GetValue("id")

    End Sub

    Private Async Sub button13_Click(sender As Object, e As EventArgs) Handles button13.Click

        Dim url As String = ""
        Dim objCamposCadastrar = textoEntrada.Text

        If optionProduction.Checked Then
            url = "https://pix.tecnospeed.com.br/api/v1/accounts/"
        Else
            url = "https://pix.tecnospeed.com.br/sandbox/accounts/"
        End If

        Dim client = New RestClient(url)
        Dim request = New RestRequest()

        request.Method = Method.Delete
        textoResposta.Text = ""
        request.AddHeader("cache-control", "no-cache")
        ' request.AddHeader("Content-Type", "application/json")
        request.AddHeader("Authorization", "Bearer " & boxAcessTokenCompany.Text)
        request.AddParameter("id", "e11b36d4-9732-4ce9-83d4-dd295d9d3383")

        Dim json = Await client.ExecuteAsync(request)
        If json.StatusCode = 204 Then
            textoResposta.Text = "Account excluida"
        Else
            textoResposta.Text = json.ErrorMessage
        End If


    End Sub

    Private Sub tabPage3_Click(sender As Object, e As EventArgs) Handles tabPage3.Click

    End Sub

    Private Sub btnOrientacaoPix_Click(sender As Object, e As EventArgs) Handles btnOrientacaoPix.Click

        textoOrientacao.Text = vbLf & " " & "Realizando a emissão de um PIX " & vbLf & "- Selecione o botão 'exemplo', para ser exibido um JSON " & vbLf & "- Após editar o JSON informado, selecione o botão 'Emitir Pix' " & vbLf & "- Como resposta da API, será retornado um ID de identificação do pix emitido, com ele podemos consultar e solicitar a imagem do QrCode " & vbLf

    End Sub

    Private Async Sub btnEmitirPix_Click(sender As Object, e As EventArgs) Handles btnEmitirPix.Click

        Dim url As String = ""
        Dim objCamposPix = textoEntrada.Text

        If optionProduction.Checked Then
            url = "https://pix.tecnospeed.com.br/api/v1/pix/dynamic"
        Else
            url = " https://pix.tecnospeed.com.br/sandbox/pix/dynamic"
        End If

        Dim client = New RestClient(url)
        Dim request = New RestRequest()
        textoResposta.Text = ""

        request.AddHeader("cache-control", "no-cache")
        request.AddHeader("Content-Type", "application/json")
        request.AddHeader("Authorization", "Bearer " & boxAcessTokenCompany.Text)
        request.AddBody(objCamposPix, "application/json")

        Dim json = Await client.ExecutePostAsync(request)
        Dim jsonParse = JObject.Parse(json.Content)

        textoResposta.Text = JsonConvert.SerializeObject(jsonParse, Formatting.Indented)
        boxIdPix.Text = jsonParse.GetValue("id")

    End Sub

    Private Async Sub btnConsultPix_Click(sender As Object, e As EventArgs) Handles btnConsultPix.Click

        Dim url As String = ""
        Dim objCamposPix = textoEntrada.Text

        If optionProduction.Checked Then
            url = "https://pix.tecnospeed.com.br/api/v1/pix/" + boxIdPix.Text
        Else
            url = "https://pix.tecnospeed.com.br/sandbox/pix/" + boxIdPix.Text
        End If

        Dim client = New RestClient(url)
        Dim request = New RestRequest()
        textoResposta.Text = ""

        request.AddHeader("cache-control", "no-cache")
        request.AddHeader("Content-Type", "application/json")
        request.AddHeader("Authorization", "Bearer " & boxAcessTokenCompany.Text)


        Dim json = Await client.ExecuteGetAsync(request)
        Dim jsonParse = JObject.Parse(json.Content)

        textoResposta.Text = JsonConvert.SerializeObject(jsonParse, Formatting.Indented)
        boxUrlQrCode.Text = jsonParse.GetValue("URLQrCode")

    End Sub

    Private Async Sub btnEmitirCobrançacomVencimento_Click(sender As Object, e As EventArgs) Handles btnEmitirCobrançacomVencimento.Click

        Dim url As String = ""
        Dim objCamposPix = textoEntrada.Text

        If optionProduction.Checked Then
            url = "https://pix.tecnospeed.com.br/api/v1/pix/charge"
        Else
            url = "https://pix.tecnospeed.com.br/sandbox/pix/charge"
        End If

        Dim client = New RestClient(url)
        Dim request = New RestRequest()
        textoResposta.Text = ""

        request.AddHeader("cache-control", "no-cache")
        request.AddHeader("Content-Type", "application/json")
        request.AddHeader("Authorization", "Bearer " & boxAcessTokenCompany.Text)
        request.AddBody(objCamposPix, "application/json")

        Dim json = Await client.ExecutePostAsync(request)
        Dim jsonParse = JObject.Parse(json.Content)

        textoResposta.Text = JsonConvert.SerializeObject(jsonParse, Formatting.Indented)
        boxIdPix.Text = jsonParse.GetValue("id")

    End Sub

    Private Sub button20_Click(sender As Object, e As EventArgs) Handles button20.Click

        textoResposta.Text = ""
        Dim ObjCamposPix = obCamposPixCobranca()
        Dim js As JavaScriptSerializer = New JavaScriptSerializer()
        js.Serialize(ObjCamposPix)
        textoEntrada.Text = JsonConvert.SerializeObject(ObjCamposPix, Formatting.Indented)

    End Sub

    Public Function objpagamento() As Object

        Return New With {Key .amount = 10.95, Key .accountId = "Teste", Key .emv = "01001001000113"}
    End Function
    Private Sub button16_Click(sender As Object, e As EventArgs) Handles button16.Click
        textoResposta.Text = ""
        Dim ObjCamposPix = objpagamento()
        Dim js As JavaScriptSerializer = New JavaScriptSerializer()
        js.Serialize(ObjCamposPix)
        textoEntrada.Text = JsonConvert.SerializeObject(ObjCamposPix, Formatting.Indented)
    End Sub

    Private Async Sub button15_Click(sender As Object, e As EventArgs) Handles button15.Click

        Dim url As String = ""
        Dim objCamposPix = textoEntrada.Text

        If optionProduction.Checked Then
            url = "https://pix.tecnospeed.com.br/api/v1/payments"
        Else
            url = "https://pix.tecnospeed.com.br/sandbox/payments"
        End If

        Dim client = New RestClient(url)
        Dim request = New RestRequest()
        textoResposta.Text = ""


        request.AddHeader("cache-control", "no-cache")
        request.AddHeader("Content-Type", "application/json")
        request.AddHeader("Authorization", "Bearer " & boxAcessTokenCompany.Text)
        request.AddBody(objCamposPix, "application/json")

        Dim json = Await client.ExecutePostAsync(request)
        Dim jsonParse = JObject.Parse(json.Content)

        textoResposta.Text = JsonConvert.SerializeObject(jsonParse, Formatting.Indented)
        boxIDPagamento.Text = jsonParse.GetValue("id")

    End Sub

    Private Sub btnQrCode_Click(sender As Object, e As EventArgs) Handles btnQrCode.Click

    End Sub

    Private Async Sub button18_Click(sender As Object, e As EventArgs) Handles button18.Click

        Dim url As String = ""
        Dim objCamposPix = textoEntrada.Text

        If optionProduction.Checked Then
            url = "https://pix.tecnospeed.com.br/api/v1/pix/" & textoEntrada.Text
        Else
            url = "https://pix.tecnospeed.com.br/sandbox/pix/" & textoEntrada.Text
        End If

        Dim client = New RestClient(url & boxIdPix.Text)
        Dim request = New RestRequest()
        textoResposta.Text = ""

        request.AddHeader("cache-control", "no-cache")
        request.AddHeader("Content-Type", "application/json")
        request.AddHeader("Authorization", "Bearer " & boxAcessTokenCompany.Text)


        Dim json = Await client.ExecuteGetAsync(request)
        Dim jsonParse = JObject.Parse(json.Content)

        textoResposta.Text = JsonConvert.SerializeObject(jsonParse, Formatting.Indented)
        boxUrlQrCode.Text = jsonParse.GetValue("URLQrCode")
    End Sub

    Private Async Sub button17_Click(sender As Object, e As EventArgs) Handles button17.Click

        Dim url As String = ""
        Dim objCamposPix = textoEntrada.Text

        If optionProduction.Checked Then
            url = "https://pix.tecnospeed.com.br/api/v1/pix/charge/" & textoEntrada.Text
        Else
            url = "https://pix.tecnospeed.com.br/sandbox/pix/charge/" & textoEntrada.Text
        End If

        Dim client = New RestClient(url & boxIdPix.Text)
        Dim request = New RestRequest()
        textoResposta.Text = ""

        request.AddHeader("cache-control", "no-cache")
        request.AddHeader("Content-Type", "application/json")
        request.AddHeader("Authorization", "Bearer " & boxAcessTokenCompany.Text)


        Dim json = Await client.ExecuteGetAsync(request)
        Dim jsonParse = JObject.Parse(json.Content)

        textoResposta.Text = JsonConvert.SerializeObject(jsonParse, Formatting.Indented)
        boxUrlQrCode.Text = jsonParse.GetValue("URLQrCode")
    End Sub

    Private Sub Button3_Click_1(sender As Object, e As EventArgs) Handles Button3.Click
        textoOrientacao.Text = ""
        textoOrientacao.Text = "Realizar Pagamento" & vbLf & vbLf & "- Selecione o botão 'exemplo', para ser exibido um JSON  " & vbLf & vbLf & "- Após editar o JSON informado, selecione o botão 'Pagar QRcode" & vbLf & "- Analise o retorno da aplicação, caso retorne sucesso, siga para o próximo passo, em caso de falha, analise o campo erro para mais detalhes."
    End Sub

    Private Async Sub Button24_Click(sender As Object, e As EventArgs) Handles Button24.Click
        Dim url As String = ""
        Dim objCamposCadastrar = textoEntrada.Text

        If optionProduction.Checked Then
            url = "https://pix.tecnospeed.com.br/api/v1/users"
        Else
            url = "https://pix.tecnospeed.com.br/sandbox/users"
        End If

        Dim client = New RestClient(url)
        Dim request = New RestRequest()
        textoResposta.Text = ""

        request.AddHeader("cache-control", "no-cache")
        request.AddHeader("Content-Type", "application/json")
        request.AddHeader("Authorization", "Bearer " & boxAcessTokenCompany.Text)
        request.AddBody(objCamposCadastrar, "application/json")


        Dim json = Await client.ExecutePostAsync(request)
        Dim jsonParse = JObject.Parse(json.Content)

        textoResposta.Text = JsonConvert.SerializeObject(jsonParse, Formatting.Indented)
    End Sub

    Private Sub BackgroundWorker1_DoWork(sender As Object, e As System.ComponentModel.DoWorkEventArgs)

    End Sub

    Private Async Sub btntrocarcertificado_Click(sender As Object, e As EventArgs) Handles btntrocarcertificado.Click
        If String.IsNullOrEmpty(txtCertificado.Text) Then

            MessageBox.Show("Primeiro, selecione o certificado")

            Return

        End If


        textoResposta.Text = ""
        Dim ObjCamposConta = New With {Key .description = "Certificado de teste", Key .password = txtSenhaCertificado.Text, Key .extension = txtExtension.Text, Key .accountId = txtAccountId.Text, Key .file = File.ReadAllBytes(txtCertificado.Text)}
        Dim js As JavaScriptSerializer = New JavaScriptSerializer()
        js.Serialize(ObjCamposConta)
        textoEntrada.Text = JsonConvert.SerializeObject(ObjCamposConta, Formatting.Indented)



        Dim url As String = ""
        Dim email As String = boxShEmail.Text
        Dim password As String = boxShSenha.Text
        Dim uploadCertificado = textoEntrada.Text

        If optionProduction.Checked Then
            url = "https://pix.tecnospeed.com.br/api/v1/certificate/" + txtAccountId.Text
        Else
            url = "https://pix.tecnospeed.com.br/sandbox/certificate/" + txtAccountId.Text
        End If

        Dim client = New RestClient(url)
        Dim request = New RestRequest()
        textoResposta.Text = ""

        request.AddHeader("cache-control", "no-cache")
        request.AddHeader("Content-Type", "application/json")
        request.AddHeader("Authorization", "Bearer " & boxAcessTokenCompany.Text)
        request.AddBody(uploadCertificado, "multipart/form-data")
        'request.AddFile("file", txtCertificado.Text)
        'request.AddParameter("file", File.ReadAllBytes(txtCertificado.Text), ParameterType.RequestBody)






        Dim json = Await client.ExecutePutAsync(request)
        Dim jsonParse = JObject.Parse(json.Content)

        textoResposta.Text = JsonConvert.SerializeObject(jsonParse, Formatting.Indented)

        boxAcessTokenSh.Text = jsonParse.GetValue("access_token")

    End Sub



    Private Async Sub btnlistarcertificados_Click(sender As Object, e As EventArgs) Handles btnlistarcertificados.Click
        Dim url As String = ""
        Dim objCamposCadastrar = textoEntrada.Text

        If optionProduction.Checked Then
            url = "https://pix.tecnospeed.com.br/api/v1/certificate"
        Else
            url = "https://pix.tecnospeed.com.br/sandbox/certificate"
        End If

        Dim client = New RestClient(url)
        Dim request = New RestRequest()
        textoResposta.Text = ""

        request.AddHeader("cache-control", "no-cache")
        request.AddHeader("Content-Type", "application/json")
        request.AddHeader("Authorization", "Bearer " & boxAcessTokenCompany.Text)
        request.AddBody(objCamposCadastrar, "application/json")


        Dim json = Await client.ExecuteGetAsync(request)
        Dim jsonParse = JObject.Parse(json.Content)

        textoResposta.Text = JsonConvert.SerializeObject(jsonParse, Formatting.Indented)
        boxIdCompany.Text = jsonParse.GetValue("id")
    End Sub

    Private Sub btnSelecionarCertificado_Click(sender As Object, e As EventArgs) Handles btnSelecionarCertificado.Click

        If openCertificado.ShowDialog() = DialogResult.OK Then
            txtCertificado.Text = openCertificado.FileName
            txtExtension.Text = Path.GetExtension(openCertificado.FileName).Replace(".", "")

        End If


    End Sub

    Private Sub openCertificado_FileOk(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles openCertificado.FileOk

    End Sub




    Private Async Sub btnuploadcertificado_Click(sender As Object, e As EventArgs) Handles btnuploadcertificado.Click

        If String.IsNullOrEmpty(txtCertificado.Text) Then

            MessageBox.Show("Primeiro, selecione o certificado")

            Return

        End If


        textoResposta.Text = ""
        Dim ObjCamposConta = New With {Key .description = "Certificado de teste", Key .password = txtSenhaCertificado.Text, Key .extension = txtExtension.Text, Key .accountId = txtAccountId.Text, Key .file = File.ReadAllBytes(txtCertificado.Text)}
        Dim js As JavaScriptSerializer = New JavaScriptSerializer()
        js.Serialize(ObjCamposConta)
        textoEntrada.Text = JsonConvert.SerializeObject(ObjCamposConta, Formatting.Indented)



        Dim url As String = ""
        Dim email As String = boxShEmail.Text
        Dim password As String = boxShSenha.Text
        Dim uploadCertificado = textoEntrada.Text

        If optionProduction.Checked Then
            url = "https://pix.tecnospeed.com.br/api/v1/certificate/upload"
        Else
            url = "https://pix.tecnospeed.com.br/sandbox/certificate/upload"
        End If

        Dim client = New RestClient(url)
        Dim request = New RestRequest()
        textoResposta.Text = ""

        request.AddHeader("cache-control", "no-cache")
        request.AddHeader("Content-Type", "application/json")
        request.AddHeader("Authorization", "Bearer " & boxAcessTokenCompany.Text)
        request.AddBody(uploadCertificado, "multipart/form-data")
        'request.AddFile("file", txtCertificado.Text)
        'request.AddParameter("file", File.ReadAllBytes(txtCertificado.Text), ParameterType.RequestBody)






        Dim json = Await client.ExecutePostAsync(request)
        Dim jsonParse = JObject.Parse(json.Content)

        textoResposta.Text = JsonConvert.SerializeObject(jsonParse, Formatting.Indented)

        boxAcessTokenSh.Text = jsonParse.GetValue("access_token")


    End Sub

    Private Async Sub Button19_Click(sender As Object, e As EventArgs) Handles Button19.Click
        Dim url As String = ""
        Dim objCamposCadastrar = textoEntrada.Text

        If optionProduction.Checked Then
            url = "https://pix.tecnospeed.com.br/api/v1/users/" + TextBoxUserID.Text
        Else
            url = "https://pix.tecnospeed.com.br/sandbox/users/" + TextBoxUserID.Text
        End If

        Dim client = New RestClient(url & boxIdPix.Text)
        Dim request = New RestRequest()
        textoResposta.Text = ""

        request.AddHeader("cache-control", "no-cache")
        request.AddHeader("Content-Type", "application/json")
        request.AddHeader("Authorization", "Bearer " & boxAcessTokenCompany.Text)
        request.AddBody(objCamposCadastrar, "application/json")


        Dim json = Await client.ExecutePutAsync(request)
        Dim jsonParse = JObject.Parse(json.Content)

        textoResposta.Text = JsonConvert.SerializeObject(jsonParse, Formatting.Indented)
    End Sub

    Private Sub Button23_Click(sender As Object, e As EventArgs) Handles Button23.Click

        textoOrientacao.Text = ""
        textoOrientacao.Text = "Realizar o cadastro de Usuarios" & vbLf & vbLf & "- Selecione o botão de Exemplo, preencha os campos e clique em Cadastrar Usuario " & vbLf & vbLf & "- Analise o retorno da aplicação, caso retorne sucesso, siga para o próximo passo, em caso de falha, analise o campo erro para mais detalhes."

    End Sub

    Private Sub Button26_Click(sender As Object, e As EventArgs) Handles Button26.Click

        textoOrientacao.Text = ""
        textoOrientacao.Text = "Realizar a inclusão de certificado digital" & vbLf & vbLf & "- Selecione o botão 'Selecionar Certificado', e selecione o certificado digital  " & vbLf & vbLf & "- Preencha os campos 'Senha do Certificado', 'AccountID' e clique em 'Upload Certificado'" & vbLf & "- Analise o retorno da aplicação, caso retorne sucesso, siga para o próximo passo, em caso de falha, analise o campo erro para mais detalhes."

    End Sub
    Public Function objuser() As Object

        Return New With {Key .name = 10.95, Key .email = "Teste", Key .description = "01001001000113"}

    End Function
    Private Sub Button25_Click(sender As Object, e As EventArgs) Handles Button25.Click
        textoResposta.Text = ""
        Dim ObjCamposPix = objuser()
        Dim js As JavaScriptSerializer = New JavaScriptSerializer()
        js.Serialize(ObjCamposPix)
        textoEntrada.Text = JsonConvert.SerializeObject(ObjCamposPix, Formatting.Indented)

    End Sub

    Private Sub Button30_Click(sender As Object, e As EventArgs) Handles Button30.Click

        textoOrientacao.Text = ""
        textoOrientacao.Text = "Realizar o cadastro de WebHook" & vbLf & vbLf & "- Selecione o botão de Exemplo, preencha os campos e clique em Cadastrar WebHook" & vbLf & vbLf & "- Analise o retorno da aplicação, caso retorne sucesso, siga para o próximo passo, em caso de falha, analise o campo erro para mais detalhes."
    End Sub

    Private Async Sub Button31_Click(sender As Object, e As EventArgs) Handles Button31.Click
        Dim url As String = ""
        Dim objCamposCadastrar = textoEntrada.Text

        If optionProduction.Checked Then
            url = "https://pix.tecnospeed.com.br/api/v1/webhook"
        Else
            url = "https://pix.tecnospeed.com.br/sandbox/webhook"
        End If

        Dim client = New RestClient(url & boxIdPix.Text)
        Dim request = New RestRequest()
        textoResposta.Text = ""

        request.AddHeader("cache-control", "no-cache")
        request.AddHeader("Content-Type", "application/json")
        request.AddHeader("Authorization", "Bearer " & boxAcessTokenCompany.Text)
        request.AddBody(objCamposCadastrar, "application/json")


        Dim json = Await client.ExecutePostAsync(request)
        Dim jsonParse = JObject.Parse(json.Content)

        textoResposta.Text = JsonConvert.SerializeObject(jsonParse, Formatting.Indented)
    End Sub

    Private Async Sub Button27_Click(sender As Object, e As EventArgs) Handles Button27.Click
        Dim url As String = ""
        Dim objCamposCadastrar = textoEntrada.Text

        If optionProduction.Checked Then
            url = "https://pix.tecnospeed.com.br/api/v1/webhook" + webhookid.Text
        Else
            url = "https://pix.tecnospeed.com.br/sandbox/webhook" + webhookid.Text
        End If

        Dim client = New RestClient(url & boxIdPix.Text)
        Dim request = New RestRequest()
        textoResposta.Text = ""

        request.AddHeader("cache-control", "no-cache")
        request.AddHeader("Content-Type", "application/json")
        request.AddHeader("Authorization", "Bearer " & boxAcessTokenCompany.Text)
        request.AddBody(objCamposCadastrar, "application/json")


        Dim json = Await client.ExecutePutAsync(request)
        Dim jsonParse = JObject.Parse(json.Content)

        textoResposta.Text = JsonConvert.SerializeObject(jsonParse, Formatting.Indented)
    End Sub

    Private Async Sub Button29_Click(sender As Object, e As EventArgs) Handles Button29.Click
        Dim url As String = ""
        Dim objCamposPix = textoEntrada.Text

        If optionProduction.Checked Then
            url = "https://pix.tecnospeed.com.br/api/v1/webhook"
        Else
            url = "https://pix.tecnospeed.com.br/sandbox/webhook"
        End If

        Dim client = New RestClient(url & boxIdPix.Text)
        Dim request = New RestRequest()
        textoResposta.Text = ""

        request.AddHeader("cache-control", "no-cache")
        request.AddHeader("Content-Type", "application/json")
        request.AddHeader("Authorization", "Bearer " & boxAcessTokenCompany.Text)


        Dim json = Await client.ExecuteGetAsync(request)
        Dim jsonParse = JObject.Parse(json.Content)

        textoResposta.Text = JsonConvert.SerializeObject(jsonParse, Formatting.Indented)
    End Sub

    Private Async Sub Button22_Click(sender As Object, e As EventArgs) Handles Button22.Click

        Dim url As String = ""
        Dim objCamposCadastrar = textoEntrada.Text

        If optionProduction.Checked Then
            url = "https://pix.tecnospeed.com.br/api/v1/users"
        Else
            url = "https://pix.tecnospeed.com.br/sandbox/users"
        End If

        Dim client = New RestClient(url)
        Dim request = New RestRequest()
        textoResposta.Text = ""

        request.AddHeader("cache-control", "no-cache")
        request.AddHeader("Content-Type", "application/json")
        request.AddHeader("Authorization", "Bearer " & boxAcessTokenCompany.Text)
        request.AddBody(objCamposCadastrar, "application/json")


        Dim json = Await client.ExecuteGetAsync(request)
        Dim jsonParse = JObject.Parse(json.Content)

        textoResposta.Text = JsonConvert.SerializeObject(jsonParse, Formatting.Indented)
        boxIdCompany.Text = jsonParse.GetValue("id")
    End Sub

    Private Sub Button21_Click(sender As Object, e As EventArgs) Handles Button21.Click
        textoResposta.Text = ""
        Dim ObjCamposPix = objuser()
        Dim js As JavaScriptSerializer = New JavaScriptSerializer()
        js.Serialize(ObjCamposPix)
        textoEntrada.Text = JsonConvert.SerializeObject(ObjCamposPix, Formatting.Indented)

    End Sub

    Public Function objwebhook() As Object

        Return New With {Key .onEvents = "PIX_SUCCESSFUL", Key .method = "POST", Key .url = "http://minhaapi.com/callback", Key .headers = "", .ContentType = "application/json", Key .Authorization = "Basic bWV1IHNlZ3JlZG8="}
    End Function
    Private Sub Button32_Click(sender As Object, e As EventArgs) Handles Button32.Click
        textoResposta.Text = ""
        Dim ObjCamposPix = objwebhook()
        Dim js As JavaScriptSerializer = New JavaScriptSerializer()
        js.Serialize(ObjCamposPix)
        textoEntrada.Text = JsonConvert.SerializeObject(ObjCamposPix, Formatting.Indented)

    End Sub

    Private Sub tabPage8_Click(sender As Object, e As EventArgs) Handles tabPage8.Click
        textoResposta.Text = ""
        Dim ObjCamposPix = objwebhook()
        Dim js As JavaScriptSerializer = New JavaScriptSerializer()
        js.Serialize(ObjCamposPix)
        textoEntrada.Text = JsonConvert.SerializeObject(ObjCamposPix, Formatting.Indented)

    End Sub

    Private Sub Button28_Click(sender As Object, e As EventArgs) Handles Button28.Click

    End Sub

    Private Sub Button34_Click(sender As Object, e As EventArgs) Handles Button34.Click
        textoResposta.Text = ""
        Dim ObjCamposPix = objwebhook()
        Dim js As JavaScriptSerializer = New JavaScriptSerializer()
        js.Serialize(ObjCamposPix)
        textoEntrada.Text = JsonConvert.SerializeObject(ObjCamposPix, Formatting.Indented)

    End Sub

    Private Async Sub Button33_Click(sender As Object, e As EventArgs) Handles Button33.Click
        Dim url As String = ""
        Dim objCamposCadastrar = textoEntrada.Text

        If optionProduction.Checked Then
            url = "https://pix.tecnospeed.com.br/api/v1/webhook"
        Else
            url = "https://pix.tecnospeed.com.br/sandbox/webhook"
        End If

        Dim client = New RestClient(url)
        Dim request = New RestRequest()

        textoResposta.Text = ""

        request.Method = Method.Patch
        request.AddHeader("cache-control", "no-cache")
        request.AddHeader("Content-Type", "application/json")
        request.AddHeader("Authorization", "Bearer " & boxAcessTokenCompany.Text)
        request.AddBody(objCamposCadastrar, "application/json")


        Dim json = Await client.ExecuteAsync(request)
        Dim jsonParse = JObject.Parse(json.Content)

        textoResposta.Text = JsonConvert.SerializeObject(jsonParse, Formatting.Indented)
        boxIdCompany.Text = jsonParse.GetValue("id")
    End Sub

    Private Sub Label27_Click(sender As Object, e As EventArgs) Handles Label27.Click

    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles webhookid.TextChanged

    End Sub

    Private Sub Button36_Click(sender As Object, e As EventArgs) Handles Button36.Click
        textoResposta.Text = ""
        Dim ObjCamposPix = objuser()
        Dim js As JavaScriptSerializer = New JavaScriptSerializer()
        js.Serialize(ObjCamposPix)
        textoEntrada.Text = JsonConvert.SerializeObject(ObjCamposPix, Formatting.Indented)

    End Sub

    Private Sub tabPage7_Click(sender As Object, e As EventArgs) Handles tabPage7.Click

    End Sub

    Private Async Sub Button35_Click(sender As Object, e As EventArgs) Handles Button35.Click
        Dim url As String = ""
        Dim objCamposCadastrar = textoEntrada.Text

        If optionProduction.Checked Then
            url = "https://pix.tecnospeed.com.br/api/v1/users/" + TextBoxUserID.Text
        Else
            url = "https://pix.tecnospeed.com.br/sandbox/users/" + TextBoxUserID.Text
        End If

        Dim client = New RestClient(url)
        Dim request = New RestRequest()

        textoResposta.Text = ""

        request.Method = Method.Patch
        request.AddHeader("cache-control", "no-cache")
        request.AddHeader("Content-Type", "application/json")
        request.AddHeader("Authorization", "Bearer " & boxAcessTokenCompany.Text)
        request.AddBody(objCamposCadastrar, "application/json")


        Dim json = Await client.ExecuteAsync(request)
        Dim jsonParse = JObject.Parse(json.Content)

        textoResposta.Text = JsonConvert.SerializeObject(jsonParse, Formatting.Indented)
        boxIdCompany.Text = jsonParse.GetValue("id")

    End Sub
End Class
