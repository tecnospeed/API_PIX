﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.tabControl1 = New System.Windows.Forms.TabControl()
        Me.tabPage1 = New System.Windows.Forms.TabPage()
        Me.label2 = New System.Windows.Forms.Label()
        Me.btnOrientacaoAutenticar = New System.Windows.Forms.Button()
        Me.label10 = New System.Windows.Forms.Label()
        Me.boxAcessTokenCompany = New System.Windows.Forms.TextBox()
        Me.label7 = New System.Windows.Forms.Label()
        Me.boxAcessTokenSh = New System.Windows.Forms.TextBox()
        Me.btnAutenticaExemploCompany = New System.Windows.Forms.Button()
        Me.btnExemploSh = New System.Windows.Forms.Button()
        Me.label5 = New System.Windows.Forms.Label()
        Me.label6 = New System.Windows.Forms.Label()
        Me.boxCompanyClientSecret = New System.Windows.Forms.TextBox()
        Me.boxCompanyClientID = New System.Windows.Forms.TextBox()
        Me.btnAutenticaCompany = New System.Windows.Forms.Button()
        Me.btnAutenticaSh = New System.Windows.Forms.Button()
        Me.label4 = New System.Windows.Forms.Label()
        Me.label3 = New System.Windows.Forms.Label()
        Me.boxShSenha = New System.Windows.Forms.TextBox()
        Me.boxShEmail = New System.Windows.Forms.TextBox()
        Me.label1 = New System.Windows.Forms.Label()
        Me.optionProduction = New System.Windows.Forms.RadioButton()
        Me.optionStaging = New System.Windows.Forms.RadioButton()
        Me.tabPage2 = New System.Windows.Forms.TabPage()
        Me.button6 = New System.Windows.Forms.Button()
        Me.button7 = New System.Windows.Forms.Button()
        Me.label17 = New System.Windows.Forms.Label()
        Me.edtcompanyput = New System.Windows.Forms.TextBox()
        Me.button2 = New System.Windows.Forms.Button()
        Me.button5 = New System.Windows.Forms.Button()
        Me.label16 = New System.Windows.Forms.Label()
        Me.edtcompanypatch = New System.Windows.Forms.TextBox()
        Me.AtualizarCompanyPut = New System.Windows.Forms.Button()
        Me.button4 = New System.Windows.Forms.Button()
        Me.button1 = New System.Windows.Forms.Button()
        Me.btnOrientacaoCompany = New System.Windows.Forms.Button()
        Me.label8 = New System.Windows.Forms.Label()
        Me.boxIdCompany = New System.Windows.Forms.TextBox()
        Me.btnCadastrarCompany = New System.Windows.Forms.Button()
        Me.btnExemploCompany = New System.Windows.Forms.Button()
        Me.tabPage3 = New System.Windows.Forms.TabPage()
        Me.button13 = New System.Windows.Forms.Button()
        Me.label19 = New System.Windows.Forms.Label()
        Me.edtaccountput = New System.Windows.Forms.TextBox()
        Me.button11 = New System.Windows.Forms.Button()
        Me.button12 = New System.Windows.Forms.Button()
        Me.label18 = New System.Windows.Forms.Label()
        Me.edtaccountpatch = New System.Windows.Forms.TextBox()
        Me.button9 = New System.Windows.Forms.Button()
        Me.button10 = New System.Windows.Forms.Button()
        Me.button8 = New System.Windows.Forms.Button()
        Me.btnOrientacaoConta = New System.Windows.Forms.Button()
        Me.label9 = New System.Windows.Forms.Label()
        Me.boxIdConta = New System.Windows.Forms.TextBox()
        Me.btnCadConta = New System.Windows.Forms.Button()
        Me.btnExemploConta = New System.Windows.Forms.Button()
        Me.tabPage4 = New System.Windows.Forms.TabPage()
        Me.label20 = New System.Windows.Forms.Label()
        Me.BoxPixCharge = New System.Windows.Forms.TextBox()
        Me.button17 = New System.Windows.Forms.Button()
        Me.button18 = New System.Windows.Forms.Button()
        Me.label21 = New System.Windows.Forms.Label()
        Me.textBox2 = New System.Windows.Forms.TextBox()
        Me.btnEmitirCobrançacomVencimento = New System.Windows.Forms.Button()
        Me.button20 = New System.Windows.Forms.Button()
        Me.btnOrientacaoPix = New System.Windows.Forms.Button()
        Me.label12 = New System.Windows.Forms.Label()
        Me.boxUrlQrCode = New System.Windows.Forms.TextBox()
        Me.btnQrCode = New System.Windows.Forms.Button()
        Me.btnConsultPix = New System.Windows.Forms.Button()
        Me.label11 = New System.Windows.Forms.Label()
        Me.boxIdPix = New System.Windows.Forms.TextBox()
        Me.btnEmitirPix = New System.Windows.Forms.Button()
        Me.btnExemploPix = New System.Windows.Forms.Button()
        Me.tabPage5 = New System.Windows.Forms.TabPage()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.boxIDPagamento = New System.Windows.Forms.TextBox()
        Me.button14 = New System.Windows.Forms.Button()
        Me.button15 = New System.Windows.Forms.Button()
        Me.button16 = New System.Windows.Forms.Button()
        Me.Certificado = New System.Windows.Forms.TabPage()
        Me.Button26 = New System.Windows.Forms.Button()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.txtKey = New System.Windows.Forms.TextBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.txtAccountId = New System.Windows.Forms.TextBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.txtExtension = New System.Windows.Forms.TextBox()
        Me.senha = New System.Windows.Forms.Label()
        Me.txtSenhaCertificado = New System.Windows.Forms.TextBox()
        Me.btnSelecionarCertificado = New System.Windows.Forms.Button()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.txtCertificado = New System.Windows.Forms.TextBox()
        Me.btnlistarcertificados = New System.Windows.Forms.Button()
        Me.btntrocarcertificado = New System.Windows.Forms.Button()
        Me.btnuploadcertificado = New System.Windows.Forms.Button()
        Me.tabPage7 = New System.Windows.Forms.TabPage()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.TextBoxUserID = New System.Windows.Forms.TextBox()
        Me.Button19 = New System.Windows.Forms.Button()
        Me.Button21 = New System.Windows.Forms.Button()
        Me.Button22 = New System.Windows.Forms.Button()
        Me.Button23 = New System.Windows.Forms.Button()
        Me.Button24 = New System.Windows.Forms.Button()
        Me.Button25 = New System.Windows.Forms.Button()
        Me.tabPage8 = New System.Windows.Forms.TabPage()
        Me.Button27 = New System.Windows.Forms.Button()
        Me.Button28 = New System.Windows.Forms.Button()
        Me.Button29 = New System.Windows.Forms.Button()
        Me.Button30 = New System.Windows.Forms.Button()
        Me.Button31 = New System.Windows.Forms.Button()
        Me.Button32 = New System.Windows.Forms.Button()
        Me.textoEntrada = New System.Windows.Forms.RichTextBox()
        Me.label15 = New System.Windows.Forms.Label()
        Me.label13 = New System.Windows.Forms.Label()
        Me.label14 = New System.Windows.Forms.Label()
        Me.textoOrientacao = New System.Windows.Forms.RichTextBox()
        Me.textoResposta = New System.Windows.Forms.RichTextBox()
        Me.openCertificado = New System.Windows.Forms.OpenFileDialog()
        Me.Button33 = New System.Windows.Forms.Button()
        Me.Button34 = New System.Windows.Forms.Button()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.webhookid = New System.Windows.Forms.TextBox()
        Me.Button35 = New System.Windows.Forms.Button()
        Me.Button36 = New System.Windows.Forms.Button()
        Me.tabControl1.SuspendLayout()
        Me.tabPage1.SuspendLayout()
        Me.tabPage2.SuspendLayout()
        Me.tabPage3.SuspendLayout()
        Me.tabPage4.SuspendLayout()
        Me.tabPage5.SuspendLayout()
        Me.Certificado.SuspendLayout()
        Me.tabPage7.SuspendLayout()
        Me.tabPage8.SuspendLayout()
        Me.SuspendLayout()
        '
        'tabControl1
        '
        Me.tabControl1.AccessibleRole = System.Windows.Forms.AccessibleRole.OutlineButton
        Me.tabControl1.Controls.Add(Me.tabPage1)
        Me.tabControl1.Controls.Add(Me.tabPage2)
        Me.tabControl1.Controls.Add(Me.tabPage3)
        Me.tabControl1.Controls.Add(Me.tabPage4)
        Me.tabControl1.Controls.Add(Me.tabPage5)
        Me.tabControl1.Controls.Add(Me.Certificado)
        Me.tabControl1.Controls.Add(Me.tabPage7)
        Me.tabControl1.Controls.Add(Me.tabPage8)
        Me.tabControl1.Location = New System.Drawing.Point(22, 18)
        Me.tabControl1.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.tabControl1.Multiline = True
        Me.tabControl1.Name = "tabControl1"
        Me.tabControl1.SelectedIndex = 0
        Me.tabControl1.Size = New System.Drawing.Size(738, 1074)
        Me.tabControl1.TabIndex = 1
        '
        'tabPage1
        '
        Me.tabPage1.BackColor = System.Drawing.Color.White
        Me.tabPage1.Controls.Add(Me.label2)
        Me.tabPage1.Controls.Add(Me.btnOrientacaoAutenticar)
        Me.tabPage1.Controls.Add(Me.label10)
        Me.tabPage1.Controls.Add(Me.boxAcessTokenCompany)
        Me.tabPage1.Controls.Add(Me.label7)
        Me.tabPage1.Controls.Add(Me.boxAcessTokenSh)
        Me.tabPage1.Controls.Add(Me.btnAutenticaExemploCompany)
        Me.tabPage1.Controls.Add(Me.btnExemploSh)
        Me.tabPage1.Controls.Add(Me.label5)
        Me.tabPage1.Controls.Add(Me.label6)
        Me.tabPage1.Controls.Add(Me.boxCompanyClientSecret)
        Me.tabPage1.Controls.Add(Me.boxCompanyClientID)
        Me.tabPage1.Controls.Add(Me.btnAutenticaCompany)
        Me.tabPage1.Controls.Add(Me.btnAutenticaSh)
        Me.tabPage1.Controls.Add(Me.label4)
        Me.tabPage1.Controls.Add(Me.label3)
        Me.tabPage1.Controls.Add(Me.boxShSenha)
        Me.tabPage1.Controls.Add(Me.boxShEmail)
        Me.tabPage1.Controls.Add(Me.label1)
        Me.tabPage1.Controls.Add(Me.optionProduction)
        Me.tabPage1.Controls.Add(Me.optionStaging)
        Me.tabPage1.Location = New System.Drawing.Point(4, 34)
        Me.tabPage1.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.tabPage1.Name = "tabPage1"
        Me.tabPage1.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.tabPage1.Size = New System.Drawing.Size(730, 1036)
        Me.tabPage1.TabIndex = 0
        Me.tabPage1.Text = "Autenticação"
        '
        'label2
        '
        Me.label2.AutoSize = True
        Me.label2.Font = New System.Drawing.Font("Segoe UI", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point)
        Me.label2.Location = New System.Drawing.Point(38, 141)
        Me.label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(198, 25)
        Me.label2.TabIndex = 22
        Me.label2.Text = "Credenciais de acesso "
        '
        'btnOrientacaoAutenticar
        '
        Me.btnOrientacaoAutenticar.Location = New System.Drawing.Point(313, 27)
        Me.btnOrientacaoAutenticar.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnOrientacaoAutenticar.Name = "btnOrientacaoAutenticar"
        Me.btnOrientacaoAutenticar.Size = New System.Drawing.Size(291, 38)
        Me.btnOrientacaoAutenticar.TabIndex = 0
        Me.btnOrientacaoAutenticar.Text = "Orientação"
        Me.btnOrientacaoAutenticar.UseVisualStyleBackColor = True
        '
        'label10
        '
        Me.label10.AutoSize = True
        Me.label10.Font = New System.Drawing.Font("Segoe UI", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point)
        Me.label10.Location = New System.Drawing.Point(38, 863)
        Me.label10.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label10.Name = "label10"
        Me.label10.Size = New System.Drawing.Size(208, 25)
        Me.label10.TabIndex = 20
        Me.label10.Text = "Bearer Token Company"
        '
        'boxAcessTokenCompany
        '
        Me.boxAcessTokenCompany.Location = New System.Drawing.Point(26, 897)
        Me.boxAcessTokenCompany.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.boxAcessTokenCompany.Name = "boxAcessTokenCompany"
        Me.boxAcessTokenCompany.Size = New System.Drawing.Size(542, 31)
        Me.boxAcessTokenCompany.TabIndex = 12
        '
        'label7
        '
        Me.label7.AutoSize = True
        Me.label7.Font = New System.Drawing.Font("Segoe UI", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point)
        Me.label7.Location = New System.Drawing.Point(30, 437)
        Me.label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label7.Name = "label7"
        Me.label7.Size = New System.Drawing.Size(260, 25)
        Me.label7.TabIndex = 18
        Me.label7.Text = "Bearer Token Software House"
        '
        'boxAcessTokenSh
        '
        Me.boxAcessTokenSh.Location = New System.Drawing.Point(26, 462)
        Me.boxAcessTokenSh.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.boxAcessTokenSh.Name = "boxAcessTokenSh"
        Me.boxAcessTokenSh.Size = New System.Drawing.Size(542, 31)
        Me.boxAcessTokenSh.TabIndex = 7
        '
        'btnAutenticaExemploCompany
        '
        Me.btnAutenticaExemploCompany.Location = New System.Drawing.Point(26, 584)
        Me.btnAutenticaExemploCompany.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnAutenticaExemploCompany.Name = "btnAutenticaExemploCompany"
        Me.btnAutenticaExemploCompany.Size = New System.Drawing.Size(175, 38)
        Me.btnAutenticaExemploCompany.TabIndex = 8
        Me.btnAutenticaExemploCompany.Text = "JSON DE EXEMPLO"
        Me.btnAutenticaExemploCompany.UseVisualStyleBackColor = True
        '
        'btnExemploSh
        '
        Me.btnExemploSh.Location = New System.Drawing.Point(26, 358)
        Me.btnExemploSh.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnExemploSh.Name = "btnExemploSh"
        Me.btnExemploSh.Size = New System.Drawing.Size(175, 38)
        Me.btnExemploSh.TabIndex = 5
        Me.btnExemploSh.Text = "JSON DE EXEMPLO"
        Me.btnExemploSh.UseVisualStyleBackColor = True
        '
        'label5
        '
        Me.label5.AutoSize = True
        Me.label5.Font = New System.Drawing.Font("Segoe UI", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point)
        Me.label5.Location = New System.Drawing.Point(41, 769)
        Me.label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label5.Name = "label5"
        Me.label5.Size = New System.Drawing.Size(112, 25)
        Me.label5.TabIndex = 14
        Me.label5.Text = "ClientSecret"
        '
        'label6
        '
        Me.label6.AutoSize = True
        Me.label6.Font = New System.Drawing.Font("Segoe UI", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point)
        Me.label6.Location = New System.Drawing.Point(41, 675)
        Me.label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label6.Name = "label6"
        Me.label6.Size = New System.Drawing.Size(82, 25)
        Me.label6.TabIndex = 13
        Me.label6.Text = "ClientID"
        '
        'boxCompanyClientSecret
        '
        Me.boxCompanyClientSecret.Location = New System.Drawing.Point(26, 807)
        Me.boxCompanyClientSecret.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.boxCompanyClientSecret.Name = "boxCompanyClientSecret"
        Me.boxCompanyClientSecret.Size = New System.Drawing.Size(542, 31)
        Me.boxCompanyClientSecret.TabIndex = 11
        Me.boxCompanyClientSecret.Text = "18chukohtn5l35km38mgcgpatg90ofu65tj64dn83gh2kuh1tck5"
        '
        'boxCompanyClientID
        '
        Me.boxCompanyClientID.Location = New System.Drawing.Point(26, 712)
        Me.boxCompanyClientID.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.boxCompanyClientID.Name = "boxCompanyClientID"
        Me.boxCompanyClientID.Size = New System.Drawing.Size(542, 31)
        Me.boxCompanyClientID.TabIndex = 10
        Me.boxCompanyClientID.Text = "5c218s19tomtd8cv8osdqsc9dd"
        '
        'btnAutenticaCompany
        '
        Me.btnAutenticaCompany.Location = New System.Drawing.Point(209, 584)
        Me.btnAutenticaCompany.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnAutenticaCompany.Name = "btnAutenticaCompany"
        Me.btnAutenticaCompany.Size = New System.Drawing.Size(359, 38)
        Me.btnAutenticaCompany.TabIndex = 9
        Me.btnAutenticaCompany.Text = "Autenticar Company"
        Me.btnAutenticaCompany.UseVisualStyleBackColor = True
        '
        'btnAutenticaSh
        '
        Me.btnAutenticaSh.Location = New System.Drawing.Point(209, 358)
        Me.btnAutenticaSh.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnAutenticaSh.Name = "btnAutenticaSh"
        Me.btnAutenticaSh.Size = New System.Drawing.Size(359, 38)
        Me.btnAutenticaSh.TabIndex = 6
        Me.btnAutenticaSh.Text = "Autenticar Software House"
        Me.btnAutenticaSh.UseVisualStyleBackColor = True
        '
        'label4
        '
        Me.label4.AutoSize = True
        Me.label4.Font = New System.Drawing.Font("Segoe UI", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point)
        Me.label4.Location = New System.Drawing.Point(41, 251)
        Me.label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label4.Name = "label4"
        Me.label4.Size = New System.Drawing.Size(69, 25)
        Me.label4.TabIndex = 8
        Me.label4.Text = "Senha "
        '
        'label3
        '
        Me.label3.AutoSize = True
        Me.label3.Font = New System.Drawing.Font("Segoe UI", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point)
        Me.label3.Location = New System.Drawing.Point(41, 199)
        Me.label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label3.Name = "label3"
        Me.label3.Size = New System.Drawing.Size(73, 25)
        Me.label3.TabIndex = 7
        Me.label3.Text = "E-mail "
        '
        'boxShSenha
        '
        Me.boxShSenha.Location = New System.Drawing.Point(111, 246)
        Me.boxShSenha.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.boxShSenha.Name = "boxShSenha"
        Me.boxShSenha.Size = New System.Drawing.Size(312, 31)
        Me.boxShSenha.TabIndex = 4
        Me.boxShSenha.Text = "12345"
        '
        'boxShEmail
        '
        Me.boxShEmail.Location = New System.Drawing.Point(111, 191)
        Me.boxShEmail.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.boxShEmail.Name = "boxShEmail"
        Me.boxShEmail.Size = New System.Drawing.Size(312, 31)
        Me.boxShEmail.TabIndex = 3
        Me.boxShEmail.Text = "pedro.bravin@tecnospeed.com.br"
        '
        'label1
        '
        Me.label1.AutoSize = True
        Me.label1.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.label1.Location = New System.Drawing.Point(41, 32)
        Me.label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(95, 25)
        Me.label1.TabIndex = 3
        Me.label1.Text = "Ambiente"
        '
        'optionProduction
        '
        Me.optionProduction.AutoSize = True
        Me.optionProduction.Location = New System.Drawing.Point(167, 80)
        Me.optionProduction.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.optionProduction.Name = "optionProduction"
        Me.optionProduction.Size = New System.Drawing.Size(119, 29)
        Me.optionProduction.TabIndex = 2
        Me.optionProduction.Text = "Protuction"
        Me.optionProduction.UseVisualStyleBackColor = True
        '
        'optionStaging
        '
        Me.optionStaging.AutoSize = True
        Me.optionStaging.Checked = True
        Me.optionStaging.Location = New System.Drawing.Point(41, 80)
        Me.optionStaging.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.optionStaging.Name = "optionStaging"
        Me.optionStaging.Size = New System.Drawing.Size(97, 29)
        Me.optionStaging.TabIndex = 1
        Me.optionStaging.TabStop = True
        Me.optionStaging.Text = "Staging"
        Me.optionStaging.UseVisualStyleBackColor = True
        '
        'tabPage2
        '
        Me.tabPage2.BackColor = System.Drawing.Color.White
        Me.tabPage2.Controls.Add(Me.button6)
        Me.tabPage2.Controls.Add(Me.button7)
        Me.tabPage2.Controls.Add(Me.label17)
        Me.tabPage2.Controls.Add(Me.edtcompanyput)
        Me.tabPage2.Controls.Add(Me.button2)
        Me.tabPage2.Controls.Add(Me.button5)
        Me.tabPage2.Controls.Add(Me.label16)
        Me.tabPage2.Controls.Add(Me.edtcompanypatch)
        Me.tabPage2.Controls.Add(Me.AtualizarCompanyPut)
        Me.tabPage2.Controls.Add(Me.button4)
        Me.tabPage2.Controls.Add(Me.button1)
        Me.tabPage2.Controls.Add(Me.btnOrientacaoCompany)
        Me.tabPage2.Controls.Add(Me.label8)
        Me.tabPage2.Controls.Add(Me.boxIdCompany)
        Me.tabPage2.Controls.Add(Me.btnCadastrarCompany)
        Me.tabPage2.Controls.Add(Me.btnExemploCompany)
        Me.tabPage2.Location = New System.Drawing.Point(4, 34)
        Me.tabPage2.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.tabPage2.Name = "tabPage2"
        Me.tabPage2.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.tabPage2.Size = New System.Drawing.Size(730, 1036)
        Me.tabPage2.TabIndex = 1
        Me.tabPage2.Text = "Company"
        '
        'button6
        '
        Me.button6.Location = New System.Drawing.Point(224, 707)
        Me.button6.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.button6.Name = "button6"
        Me.button6.Size = New System.Drawing.Size(341, 38)
        Me.button6.TabIndex = 12
        Me.button6.Text = "Desativar Company"
        Me.button6.UseVisualStyleBackColor = True
        '
        'button7
        '
        Me.button7.Location = New System.Drawing.Point(37, 707)
        Me.button7.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.button7.Name = "button7"
        Me.button7.Size = New System.Drawing.Size(179, 38)
        Me.button7.TabIndex = 11
        Me.button7.Text = "JSON DE EXEMPLO"
        Me.button7.UseVisualStyleBackColor = True
        '
        'label17
        '
        Me.label17.AutoSize = True
        Me.label17.Font = New System.Drawing.Font("Segoe UI", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point)
        Me.label17.Location = New System.Drawing.Point(41, 603)
        Me.label17.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label17.Name = "label17"
        Me.label17.Size = New System.Drawing.Size(109, 25)
        Me.label17.TabIndex = 32
        Me.label17.Text = "CompanyId"
        '
        'edtcompanyput
        '
        Me.edtcompanyput.Location = New System.Drawing.Point(37, 628)
        Me.edtcompanyput.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.edtcompanyput.Name = "edtcompanyput"
        Me.edtcompanyput.Size = New System.Drawing.Size(528, 31)
        Me.edtcompanyput.TabIndex = 10
        '
        'button2
        '
        Me.button2.Location = New System.Drawing.Point(224, 530)
        Me.button2.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.button2.Name = "button2"
        Me.button2.Size = New System.Drawing.Size(341, 38)
        Me.button2.TabIndex = 9
        Me.button2.Text = "Atualizar Company (PUT)"
        Me.button2.UseVisualStyleBackColor = True
        '
        'button5
        '
        Me.button5.Location = New System.Drawing.Point(37, 530)
        Me.button5.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.button5.Name = "button5"
        Me.button5.Size = New System.Drawing.Size(179, 38)
        Me.button5.TabIndex = 8
        Me.button5.Text = "JSON DE EXEMPLO"
        Me.button5.UseVisualStyleBackColor = True
        '
        'label16
        '
        Me.label16.AutoSize = True
        Me.label16.Font = New System.Drawing.Font("Segoe UI", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point)
        Me.label16.Location = New System.Drawing.Point(41, 433)
        Me.label16.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label16.Name = "label16"
        Me.label16.Size = New System.Drawing.Size(109, 25)
        Me.label16.TabIndex = 28
        Me.label16.Text = "CompanyId"
        '
        'edtcompanypatch
        '
        Me.edtcompanypatch.Location = New System.Drawing.Point(37, 458)
        Me.edtcompanypatch.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.edtcompanypatch.Name = "edtcompanypatch"
        Me.edtcompanypatch.Size = New System.Drawing.Size(528, 31)
        Me.edtcompanypatch.TabIndex = 7
        '
        'AtualizarCompanyPut
        '
        Me.AtualizarCompanyPut.Location = New System.Drawing.Point(224, 360)
        Me.AtualizarCompanyPut.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.AtualizarCompanyPut.Name = "AtualizarCompanyPut"
        Me.AtualizarCompanyPut.Size = New System.Drawing.Size(341, 38)
        Me.AtualizarCompanyPut.TabIndex = 6
        Me.AtualizarCompanyPut.Text = "Atualizar Company (Patch)"
        Me.AtualizarCompanyPut.UseVisualStyleBackColor = True
        '
        'button4
        '
        Me.button4.Location = New System.Drawing.Point(37, 360)
        Me.button4.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.button4.Name = "button4"
        Me.button4.Size = New System.Drawing.Size(179, 38)
        Me.button4.TabIndex = 5
        Me.button4.Text = "JSON DE EXEMPLO"
        Me.button4.UseVisualStyleBackColor = True
        '
        'button1
        '
        Me.button1.Location = New System.Drawing.Point(37, 276)
        Me.button1.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.button1.Name = "button1"
        Me.button1.Size = New System.Drawing.Size(528, 38)
        Me.button1.TabIndex = 4
        Me.button1.Text = "Listar Companys"
        Me.button1.UseVisualStyleBackColor = True
        '
        'btnOrientacaoCompany
        '
        Me.btnOrientacaoCompany.Location = New System.Drawing.Point(318, 31)
        Me.btnOrientacaoCompany.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnOrientacaoCompany.Name = "btnOrientacaoCompany"
        Me.btnOrientacaoCompany.Size = New System.Drawing.Size(291, 38)
        Me.btnOrientacaoCompany.TabIndex = 0
        Me.btnOrientacaoCompany.Text = "Orientação"
        Me.btnOrientacaoCompany.UseVisualStyleBackColor = True
        '
        'label8
        '
        Me.label8.AutoSize = True
        Me.label8.Font = New System.Drawing.Font("Segoe UI", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point)
        Me.label8.Location = New System.Drawing.Point(41, 167)
        Me.label8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label8.Name = "label8"
        Me.label8.Size = New System.Drawing.Size(109, 25)
        Me.label8.TabIndex = 3
        Me.label8.Text = "CompanyId"
        '
        'boxIdCompany
        '
        Me.boxIdCompany.Location = New System.Drawing.Point(37, 192)
        Me.boxIdCompany.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.boxIdCompany.Name = "boxIdCompany"
        Me.boxIdCompany.Size = New System.Drawing.Size(528, 31)
        Me.boxIdCompany.TabIndex = 3
        '
        'btnCadastrarCompany
        '
        Me.btnCadastrarCompany.Location = New System.Drawing.Point(224, 104)
        Me.btnCadastrarCompany.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnCadastrarCompany.Name = "btnCadastrarCompany"
        Me.btnCadastrarCompany.Size = New System.Drawing.Size(341, 38)
        Me.btnCadastrarCompany.TabIndex = 2
        Me.btnCadastrarCompany.Text = "Cadastrar Company"
        Me.btnCadastrarCompany.UseVisualStyleBackColor = True
        '
        'btnExemploCompany
        '
        Me.btnExemploCompany.Location = New System.Drawing.Point(37, 104)
        Me.btnExemploCompany.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnExemploCompany.Name = "btnExemploCompany"
        Me.btnExemploCompany.Size = New System.Drawing.Size(179, 38)
        Me.btnExemploCompany.TabIndex = 1
        Me.btnExemploCompany.Text = "JSON DE EXEMPLO"
        Me.btnExemploCompany.UseVisualStyleBackColor = True
        '
        'tabPage3
        '
        Me.tabPage3.BackColor = System.Drawing.Color.White
        Me.tabPage3.Controls.Add(Me.button13)
        Me.tabPage3.Controls.Add(Me.label19)
        Me.tabPage3.Controls.Add(Me.edtaccountput)
        Me.tabPage3.Controls.Add(Me.button11)
        Me.tabPage3.Controls.Add(Me.button12)
        Me.tabPage3.Controls.Add(Me.label18)
        Me.tabPage3.Controls.Add(Me.edtaccountpatch)
        Me.tabPage3.Controls.Add(Me.button9)
        Me.tabPage3.Controls.Add(Me.button10)
        Me.tabPage3.Controls.Add(Me.button8)
        Me.tabPage3.Controls.Add(Me.btnOrientacaoConta)
        Me.tabPage3.Controls.Add(Me.label9)
        Me.tabPage3.Controls.Add(Me.boxIdConta)
        Me.tabPage3.Controls.Add(Me.btnCadConta)
        Me.tabPage3.Controls.Add(Me.btnExemploConta)
        Me.tabPage3.Location = New System.Drawing.Point(4, 34)
        Me.tabPage3.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.tabPage3.Name = "tabPage3"
        Me.tabPage3.Size = New System.Drawing.Size(730, 1036)
        Me.tabPage3.TabIndex = 2
        Me.tabPage3.Text = "Account"
        '
        'button13
        '
        Me.button13.Location = New System.Drawing.Point(46, 760)
        Me.button13.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.button13.Name = "button13"
        Me.button13.Size = New System.Drawing.Size(513, 38)
        Me.button13.TabIndex = 33
        Me.button13.Text = "Desativar Account"
        Me.button13.UseVisualStyleBackColor = True
        '
        'label19
        '
        Me.label19.AutoSize = True
        Me.label19.Font = New System.Drawing.Font("Segoe UI", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point)
        Me.label19.Location = New System.Drawing.Point(46, 639)
        Me.label19.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label19.Name = "label19"
        Me.label19.Size = New System.Drawing.Size(100, 25)
        Me.label19.TabIndex = 32
        Me.label19.Text = "AccountID"
        '
        'edtaccountput
        '
        Me.edtaccountput.Location = New System.Drawing.Point(46, 666)
        Me.edtaccountput.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.edtaccountput.Name = "edtaccountput"
        Me.edtaccountput.Size = New System.Drawing.Size(513, 31)
        Me.edtaccountput.TabIndex = 31
        '
        'button11
        '
        Me.button11.Location = New System.Drawing.Point(234, 578)
        Me.button11.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.button11.Name = "button11"
        Me.button11.Size = New System.Drawing.Size(325, 38)
        Me.button11.TabIndex = 30
        Me.button11.Text = "Atualizar Account (PUT)"
        Me.button11.UseVisualStyleBackColor = True
        '
        'button12
        '
        Me.button12.Location = New System.Drawing.Point(46, 578)
        Me.button12.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.button12.Name = "button12"
        Me.button12.Size = New System.Drawing.Size(180, 38)
        Me.button12.TabIndex = 29
        Me.button12.Text = "JSON DE EXEMPLO"
        Me.button12.UseVisualStyleBackColor = True
        '
        'label18
        '
        Me.label18.AutoSize = True
        Me.label18.Font = New System.Drawing.Font("Segoe UI", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point)
        Me.label18.Location = New System.Drawing.Point(46, 472)
        Me.label18.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label18.Name = "label18"
        Me.label18.Size = New System.Drawing.Size(100, 25)
        Me.label18.TabIndex = 28
        Me.label18.Text = "AccountID"
        '
        'edtaccountpatch
        '
        Me.edtaccountpatch.Location = New System.Drawing.Point(46, 499)
        Me.edtaccountpatch.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.edtaccountpatch.Name = "edtaccountpatch"
        Me.edtaccountpatch.Size = New System.Drawing.Size(513, 31)
        Me.edtaccountpatch.TabIndex = 27
        '
        'button9
        '
        Me.button9.Location = New System.Drawing.Point(234, 411)
        Me.button9.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.button9.Name = "button9"
        Me.button9.Size = New System.Drawing.Size(325, 38)
        Me.button9.TabIndex = 26
        Me.button9.Text = "Atualizar account (Patch)"
        Me.button9.UseVisualStyleBackColor = True
        '
        'button10
        '
        Me.button10.Location = New System.Drawing.Point(46, 411)
        Me.button10.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.button10.Name = "button10"
        Me.button10.Size = New System.Drawing.Size(180, 38)
        Me.button10.TabIndex = 25
        Me.button10.Text = "JSON DE EXEMPLO"
        Me.button10.UseVisualStyleBackColor = True
        '
        'button8
        '
        Me.button8.Location = New System.Drawing.Point(46, 307)
        Me.button8.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.button8.Name = "button8"
        Me.button8.Size = New System.Drawing.Size(513, 38)
        Me.button8.TabIndex = 24
        Me.button8.Text = "Listar Accounts"
        Me.button8.UseVisualStyleBackColor = True
        '
        'btnOrientacaoConta
        '
        Me.btnOrientacaoConta.Location = New System.Drawing.Point(343, 32)
        Me.btnOrientacaoConta.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnOrientacaoConta.Name = "btnOrientacaoConta"
        Me.btnOrientacaoConta.Size = New System.Drawing.Size(291, 38)
        Me.btnOrientacaoConta.TabIndex = 23
        Me.btnOrientacaoConta.Text = "Orientação"
        Me.btnOrientacaoConta.UseVisualStyleBackColor = True
        '
        'label9
        '
        Me.label9.AutoSize = True
        Me.label9.Font = New System.Drawing.Font("Segoe UI", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point)
        Me.label9.Location = New System.Drawing.Point(46, 203)
        Me.label9.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label9.Name = "label9"
        Me.label9.Size = New System.Drawing.Size(100, 25)
        Me.label9.TabIndex = 7
        Me.label9.Text = "AccountID"
        '
        'boxIdConta
        '
        Me.boxIdConta.Location = New System.Drawing.Point(46, 230)
        Me.boxIdConta.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.boxIdConta.Name = "boxIdConta"
        Me.boxIdConta.Size = New System.Drawing.Size(513, 31)
        Me.boxIdConta.TabIndex = 6
        '
        'btnCadConta
        '
        Me.btnCadConta.Location = New System.Drawing.Point(234, 142)
        Me.btnCadConta.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnCadConta.Name = "btnCadConta"
        Me.btnCadConta.Size = New System.Drawing.Size(325, 38)
        Me.btnCadConta.TabIndex = 5
        Me.btnCadConta.Text = "Cadastrar Account"
        Me.btnCadConta.UseVisualStyleBackColor = True
        '
        'btnExemploConta
        '
        Me.btnExemploConta.Location = New System.Drawing.Point(46, 142)
        Me.btnExemploConta.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnExemploConta.Name = "btnExemploConta"
        Me.btnExemploConta.Size = New System.Drawing.Size(180, 38)
        Me.btnExemploConta.TabIndex = 4
        Me.btnExemploConta.Text = "JSON DE EXEMPLO"
        Me.btnExemploConta.UseVisualStyleBackColor = True
        '
        'tabPage4
        '
        Me.tabPage4.BackColor = System.Drawing.Color.White
        Me.tabPage4.Controls.Add(Me.label20)
        Me.tabPage4.Controls.Add(Me.BoxPixCharge)
        Me.tabPage4.Controls.Add(Me.button17)
        Me.tabPage4.Controls.Add(Me.button18)
        Me.tabPage4.Controls.Add(Me.label21)
        Me.tabPage4.Controls.Add(Me.textBox2)
        Me.tabPage4.Controls.Add(Me.btnEmitirCobrançacomVencimento)
        Me.tabPage4.Controls.Add(Me.button20)
        Me.tabPage4.Controls.Add(Me.btnOrientacaoPix)
        Me.tabPage4.Controls.Add(Me.label12)
        Me.tabPage4.Controls.Add(Me.boxUrlQrCode)
        Me.tabPage4.Controls.Add(Me.btnQrCode)
        Me.tabPage4.Controls.Add(Me.btnConsultPix)
        Me.tabPage4.Controls.Add(Me.label11)
        Me.tabPage4.Controls.Add(Me.boxIdPix)
        Me.tabPage4.Controls.Add(Me.btnEmitirPix)
        Me.tabPage4.Controls.Add(Me.btnExemploPix)
        Me.tabPage4.Location = New System.Drawing.Point(4, 34)
        Me.tabPage4.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.tabPage4.Name = "tabPage4"
        Me.tabPage4.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.tabPage4.Size = New System.Drawing.Size(730, 1036)
        Me.tabPage4.TabIndex = 3
        Me.tabPage4.Text = "Emitir Pix"
        '
        'label20
        '
        Me.label20.AutoSize = True
        Me.label20.Location = New System.Drawing.Point(45, 767)
        Me.label20.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label20.Name = "label20"
        Me.label20.Size = New System.Drawing.Size(137, 25)
        Me.label20.TabIndex = 31
        Me.label20.Text = "Link do QrCode"
        '
        'BoxPixCharge
        '
        Me.BoxPixCharge.Location = New System.Drawing.Point(41, 792)
        Me.BoxPixCharge.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BoxPixCharge.Name = "BoxPixCharge"
        Me.BoxPixCharge.Size = New System.Drawing.Size(544, 31)
        Me.BoxPixCharge.TabIndex = 30
        '
        'button17
        '
        Me.button17.Location = New System.Drawing.Point(41, 716)
        Me.button17.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.button17.Name = "button17"
        Me.button17.Size = New System.Drawing.Size(544, 38)
        Me.button17.TabIndex = 29
        Me.button17.Text = "QrCode"
        Me.button17.UseVisualStyleBackColor = True
        '
        'button18
        '
        Me.button18.Location = New System.Drawing.Point(41, 668)
        Me.button18.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.button18.Name = "button18"
        Me.button18.Size = New System.Drawing.Size(544, 38)
        Me.button18.TabIndex = 28
        Me.button18.Text = "Consultar PIX"
        Me.button18.UseVisualStyleBackColor = True
        '
        'label21
        '
        Me.label21.AutoSize = True
        Me.label21.Location = New System.Drawing.Point(45, 593)
        Me.label21.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label21.Name = "label21"
        Me.label21.Size = New System.Drawing.Size(57, 25)
        Me.label21.TabIndex = 27
        Me.label21.Text = "Pix ID"
        '
        'textBox2
        '
        Me.textBox2.Location = New System.Drawing.Point(41, 614)
        Me.textBox2.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.textBox2.Name = "textBox2"
        Me.textBox2.Size = New System.Drawing.Size(544, 31)
        Me.textBox2.TabIndex = 26
        '
        'btnEmitirCobrançacomVencimento
        '
        Me.btnEmitirCobrançacomVencimento.Location = New System.Drawing.Point(223, 530)
        Me.btnEmitirCobrançacomVencimento.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnEmitirCobrançacomVencimento.Name = "btnEmitirCobrançacomVencimento"
        Me.btnEmitirCobrançacomVencimento.Size = New System.Drawing.Size(362, 38)
        Me.btnEmitirCobrançacomVencimento.TabIndex = 25
        Me.btnEmitirCobrançacomVencimento.Text = "Emitir Cobrança com Vencimento"
        Me.btnEmitirCobrançacomVencimento.UseVisualStyleBackColor = True
        '
        'button20
        '
        Me.button20.Location = New System.Drawing.Point(41, 530)
        Me.button20.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.button20.Name = "button20"
        Me.button20.Size = New System.Drawing.Size(174, 38)
        Me.button20.TabIndex = 24
        Me.button20.Text = "JSON DE EXEMPLO"
        Me.button20.UseVisualStyleBackColor = True
        '
        'btnOrientacaoPix
        '
        Me.btnOrientacaoPix.Location = New System.Drawing.Point(323, 49)
        Me.btnOrientacaoPix.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnOrientacaoPix.Name = "btnOrientacaoPix"
        Me.btnOrientacaoPix.Size = New System.Drawing.Size(291, 38)
        Me.btnOrientacaoPix.TabIndex = 23
        Me.btnOrientacaoPix.Text = "Orientação"
        Me.btnOrientacaoPix.UseVisualStyleBackColor = True
        '
        'label12
        '
        Me.label12.AutoSize = True
        Me.label12.Location = New System.Drawing.Point(45, 399)
        Me.label12.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label12.Name = "label12"
        Me.label12.Size = New System.Drawing.Size(137, 25)
        Me.label12.TabIndex = 16
        Me.label12.Text = "Link do QrCode"
        '
        'boxUrlQrCode
        '
        Me.boxUrlQrCode.Location = New System.Drawing.Point(41, 424)
        Me.boxUrlQrCode.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.boxUrlQrCode.Name = "boxUrlQrCode"
        Me.boxUrlQrCode.Size = New System.Drawing.Size(544, 31)
        Me.boxUrlQrCode.TabIndex = 15
        '
        'btnQrCode
        '
        Me.btnQrCode.Location = New System.Drawing.Point(41, 348)
        Me.btnQrCode.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnQrCode.Name = "btnQrCode"
        Me.btnQrCode.Size = New System.Drawing.Size(544, 38)
        Me.btnQrCode.TabIndex = 14
        Me.btnQrCode.Text = "QrCode"
        Me.btnQrCode.UseVisualStyleBackColor = True
        '
        'btnConsultPix
        '
        Me.btnConsultPix.Location = New System.Drawing.Point(41, 300)
        Me.btnConsultPix.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnConsultPix.Name = "btnConsultPix"
        Me.btnConsultPix.Size = New System.Drawing.Size(544, 38)
        Me.btnConsultPix.TabIndex = 12
        Me.btnConsultPix.Text = "Consultar PIX"
        Me.btnConsultPix.UseVisualStyleBackColor = True
        '
        'label11
        '
        Me.label11.AutoSize = True
        Me.label11.Location = New System.Drawing.Point(45, 225)
        Me.label11.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label11.Name = "label11"
        Me.label11.Size = New System.Drawing.Size(57, 25)
        Me.label11.TabIndex = 11
        Me.label11.Text = "Pix ID"
        '
        'boxIdPix
        '
        Me.boxIdPix.Location = New System.Drawing.Point(41, 246)
        Me.boxIdPix.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.boxIdPix.Name = "boxIdPix"
        Me.boxIdPix.Size = New System.Drawing.Size(544, 31)
        Me.boxIdPix.TabIndex = 10
        '
        'btnEmitirPix
        '
        Me.btnEmitirPix.Location = New System.Drawing.Point(223, 162)
        Me.btnEmitirPix.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnEmitirPix.Name = "btnEmitirPix"
        Me.btnEmitirPix.Size = New System.Drawing.Size(362, 38)
        Me.btnEmitirPix.TabIndex = 9
        Me.btnEmitirPix.Text = "Emitir Cobrança Imediata"
        Me.btnEmitirPix.UseVisualStyleBackColor = True
        '
        'btnExemploPix
        '
        Me.btnExemploPix.Location = New System.Drawing.Point(41, 162)
        Me.btnExemploPix.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnExemploPix.Name = "btnExemploPix"
        Me.btnExemploPix.Size = New System.Drawing.Size(174, 38)
        Me.btnExemploPix.TabIndex = 8
        Me.btnExemploPix.Text = "JSON DE EXEMPLO"
        Me.btnExemploPix.UseVisualStyleBackColor = True
        '
        'tabPage5
        '
        Me.tabPage5.Controls.Add(Me.Button3)
        Me.tabPage5.Controls.Add(Me.Label22)
        Me.tabPage5.Controls.Add(Me.boxIDPagamento)
        Me.tabPage5.Controls.Add(Me.button14)
        Me.tabPage5.Controls.Add(Me.button15)
        Me.tabPage5.Controls.Add(Me.button16)
        Me.tabPage5.Location = New System.Drawing.Point(4, 34)
        Me.tabPage5.Name = "tabPage5"
        Me.tabPage5.Padding = New System.Windows.Forms.Padding(3)
        Me.tabPage5.Size = New System.Drawing.Size(730, 1036)
        Me.tabPage5.TabIndex = 4
        Me.tabPage5.Text = "Pagamento"
        Me.tabPage5.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(325, 44)
        Me.Button3.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(291, 38)
        Me.Button3.TabIndex = 24
        Me.Button3.Text = "Orientação"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(49, 188)
        Me.Label22.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(125, 25)
        Me.Label22.TabIndex = 17
        Me.Label22.Text = "Pagamento ID"
        '
        'boxIDPagamento
        '
        Me.boxIDPagamento.Location = New System.Drawing.Point(45, 209)
        Me.boxIDPagamento.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.boxIDPagamento.Name = "boxIDPagamento"
        Me.boxIDPagamento.Size = New System.Drawing.Size(544, 31)
        Me.boxIDPagamento.TabIndex = 16
        '
        'button14
        '
        Me.button14.Location = New System.Drawing.Point(45, 274)
        Me.button14.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.button14.Name = "button14"
        Me.button14.Size = New System.Drawing.Size(544, 38)
        Me.button14.TabIndex = 15
        Me.button14.Text = "Consultar Pagamento"
        Me.button14.UseVisualStyleBackColor = True
        '
        'button15
        '
        Me.button15.Location = New System.Drawing.Point(227, 136)
        Me.button15.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.button15.Name = "button15"
        Me.button15.Size = New System.Drawing.Size(362, 38)
        Me.button15.TabIndex = 14
        Me.button15.Text = "Pagar QRcode"
        Me.button15.UseVisualStyleBackColor = True
        '
        'button16
        '
        Me.button16.Location = New System.Drawing.Point(45, 136)
        Me.button16.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.button16.Name = "button16"
        Me.button16.Size = New System.Drawing.Size(174, 38)
        Me.button16.TabIndex = 13
        Me.button16.Text = "JSON DE EXEMPLO"
        Me.button16.UseVisualStyleBackColor = True
        '
        'Certificado
        '
        Me.Certificado.Controls.Add(Me.Button26)
        Me.Certificado.Controls.Add(Me.Label26)
        Me.Certificado.Controls.Add(Me.txtKey)
        Me.Certificado.Controls.Add(Me.Label25)
        Me.Certificado.Controls.Add(Me.txtAccountId)
        Me.Certificado.Controls.Add(Me.Label24)
        Me.Certificado.Controls.Add(Me.txtExtension)
        Me.Certificado.Controls.Add(Me.senha)
        Me.Certificado.Controls.Add(Me.txtSenhaCertificado)
        Me.Certificado.Controls.Add(Me.btnSelecionarCertificado)
        Me.Certificado.Controls.Add(Me.Label23)
        Me.Certificado.Controls.Add(Me.txtCertificado)
        Me.Certificado.Controls.Add(Me.btnlistarcertificados)
        Me.Certificado.Controls.Add(Me.btntrocarcertificado)
        Me.Certificado.Controls.Add(Me.btnuploadcertificado)
        Me.Certificado.Location = New System.Drawing.Point(4, 34)
        Me.Certificado.Name = "Certificado"
        Me.Certificado.Padding = New System.Windows.Forms.Padding(3)
        Me.Certificado.Size = New System.Drawing.Size(730, 1036)
        Me.Certificado.TabIndex = 5
        Me.Certificado.Text = "Certificado"
        Me.Certificado.UseVisualStyleBackColor = True
        '
        'Button26
        '
        Me.Button26.Location = New System.Drawing.Point(387, 62)
        Me.Button26.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Button26.Name = "Button26"
        Me.Button26.Size = New System.Drawing.Size(291, 38)
        Me.Button26.TabIndex = 0
        Me.Button26.Text = "Orientação"
        Me.Button26.UseVisualStyleBackColor = True
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(91, 441)
        Me.Label26.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(40, 25)
        Me.Label26.TabIndex = 45
        Me.Label26.Text = "Key"
        '
        'txtKey
        '
        Me.txtKey.Location = New System.Drawing.Point(85, 471)
        Me.txtKey.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtKey.Name = "txtKey"
        Me.txtKey.Size = New System.Drawing.Size(544, 31)
        Me.txtKey.TabIndex = 7
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(91, 375)
        Me.Label25.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(95, 25)
        Me.Label25.TabIndex = 43
        Me.Label25.Text = "AccountID"
        '
        'txtAccountId
        '
        Me.txtAccountId.Location = New System.Drawing.Point(85, 400)
        Me.txtAccountId.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtAccountId.Name = "txtAccountId"
        Me.txtAccountId.Size = New System.Drawing.Size(544, 31)
        Me.txtAccountId.TabIndex = 6
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(91, 309)
        Me.Label24.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(201, 25)
        Me.Label24.TabIndex = 41
        Me.Label24.Text = "Extension do certificado"
        '
        'txtExtension
        '
        Me.txtExtension.Location = New System.Drawing.Point(87, 339)
        Me.txtExtension.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtExtension.Name = "txtExtension"
        Me.txtExtension.Size = New System.Drawing.Size(544, 31)
        Me.txtExtension.TabIndex = 5
        '
        'senha
        '
        Me.senha.AutoSize = True
        Me.senha.Location = New System.Drawing.Point(91, 251)
        Me.senha.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.senha.Name = "senha"
        Me.senha.Size = New System.Drawing.Size(174, 25)
        Me.senha.TabIndex = 39
        Me.senha.Text = "Senha do certificado"
        '
        'txtSenhaCertificado
        '
        Me.txtSenhaCertificado.Location = New System.Drawing.Point(87, 273)
        Me.txtSenhaCertificado.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtSenhaCertificado.Name = "txtSenhaCertificado"
        Me.txtSenhaCertificado.Size = New System.Drawing.Size(544, 31)
        Me.txtSenhaCertificado.TabIndex = 4
        '
        'btnSelecionarCertificado
        '
        Me.btnSelecionarCertificado.Location = New System.Drawing.Point(53, 152)
        Me.btnSelecionarCertificado.Name = "btnSelecionarCertificado"
        Me.btnSelecionarCertificado.Size = New System.Drawing.Size(237, 34)
        Me.btnSelecionarCertificado.TabIndex = 1
        Me.btnSelecionarCertificado.Text = "Selecionar Certificado"
        Me.btnSelecionarCertificado.UseVisualStyleBackColor = True
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(91, 194)
        Me.Label23.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(199, 25)
        Me.Label23.TabIndex = 37
        Me.Label23.Text = "Endereço do certificado"
        '
        'txtCertificado
        '
        Me.txtCertificado.Location = New System.Drawing.Point(87, 215)
        Me.txtCertificado.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtCertificado.Name = "txtCertificado"
        Me.txtCertificado.Size = New System.Drawing.Size(544, 31)
        Me.txtCertificado.TabIndex = 3
        '
        'btnlistarcertificados
        '
        Me.btnlistarcertificados.Location = New System.Drawing.Point(184, 625)
        Me.btnlistarcertificados.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnlistarcertificados.Name = "btnlistarcertificados"
        Me.btnlistarcertificados.Size = New System.Drawing.Size(325, 38)
        Me.btnlistarcertificados.TabIndex = 9
        Me.btnlistarcertificados.Text = "Listar Certificados"
        Me.btnlistarcertificados.UseVisualStyleBackColor = True
        '
        'btntrocarcertificado
        '
        Me.btntrocarcertificado.Location = New System.Drawing.Point(184, 556)
        Me.btntrocarcertificado.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btntrocarcertificado.Name = "btntrocarcertificado"
        Me.btntrocarcertificado.Size = New System.Drawing.Size(325, 38)
        Me.btntrocarcertificado.TabIndex = 8
        Me.btntrocarcertificado.Text = "Trocar Certificado"
        Me.btntrocarcertificado.UseVisualStyleBackColor = True
        '
        'btnuploadcertificado
        '
        Me.btnuploadcertificado.Location = New System.Drawing.Point(304, 150)
        Me.btnuploadcertificado.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnuploadcertificado.Name = "btnuploadcertificado"
        Me.btnuploadcertificado.Size = New System.Drawing.Size(325, 38)
        Me.btnuploadcertificado.TabIndex = 2
        Me.btnuploadcertificado.Text = "Upload Certificado"
        Me.btnuploadcertificado.UseVisualStyleBackColor = True
        '
        'tabPage7
        '
        Me.tabPage7.Controls.Add(Me.Button35)
        Me.tabPage7.Controls.Add(Me.Button36)
        Me.tabPage7.Controls.Add(Me.Label28)
        Me.tabPage7.Controls.Add(Me.TextBoxUserID)
        Me.tabPage7.Controls.Add(Me.Button19)
        Me.tabPage7.Controls.Add(Me.Button21)
        Me.tabPage7.Controls.Add(Me.Button22)
        Me.tabPage7.Controls.Add(Me.Button23)
        Me.tabPage7.Controls.Add(Me.Button24)
        Me.tabPage7.Controls.Add(Me.Button25)
        Me.tabPage7.Location = New System.Drawing.Point(4, 34)
        Me.tabPage7.Name = "tabPage7"
        Me.tabPage7.Padding = New System.Windows.Forms.Padding(3)
        Me.tabPage7.Size = New System.Drawing.Size(730, 1036)
        Me.tabPage7.TabIndex = 6
        Me.tabPage7.Text = "Usuarios"
        Me.tabPage7.UseVisualStyleBackColor = True
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(67, 199)
        Me.Label28.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(65, 25)
        Me.Label28.TabIndex = 46
        Me.Label28.Text = "UserID"
        '
        'TextBoxUserID
        '
        Me.TextBoxUserID.Location = New System.Drawing.Point(68, 217)
        Me.TextBoxUserID.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TextBoxUserID.Name = "TextBoxUserID"
        Me.TextBoxUserID.Size = New System.Drawing.Size(544, 31)
        Me.TextBoxUserID.TabIndex = 45
        '
        'Button19
        '
        Me.Button19.Location = New System.Drawing.Point(256, 277)
        Me.Button19.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Button19.Name = "Button19"
        Me.Button19.Size = New System.Drawing.Size(325, 38)
        Me.Button19.TabIndex = 4
        Me.Button19.Text = "Atualizar Usuario (PUT)"
        Me.Button19.UseVisualStyleBackColor = True
        '
        'Button21
        '
        Me.Button21.Location = New System.Drawing.Point(68, 277)
        Me.Button21.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Button21.Name = "Button21"
        Me.Button21.Size = New System.Drawing.Size(180, 38)
        Me.Button21.TabIndex = 3
        Me.Button21.Text = "JSON DE EXEMPLO"
        Me.Button21.UseVisualStyleBackColor = True
        '
        'Button22
        '
        Me.Button22.Location = New System.Drawing.Point(68, 406)
        Me.Button22.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Button22.Name = "Button22"
        Me.Button22.Size = New System.Drawing.Size(513, 38)
        Me.Button22.TabIndex = 5
        Me.Button22.Text = "Listar Accounts"
        Me.Button22.UseVisualStyleBackColor = True
        '
        'Button23
        '
        Me.Button23.Location = New System.Drawing.Point(365, 35)
        Me.Button23.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Button23.Name = "Button23"
        Me.Button23.Size = New System.Drawing.Size(291, 38)
        Me.Button23.TabIndex = 0
        Me.Button23.Text = "Orientação"
        Me.Button23.UseVisualStyleBackColor = True
        '
        'Button24
        '
        Me.Button24.Location = New System.Drawing.Point(256, 145)
        Me.Button24.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Button24.Name = "Button24"
        Me.Button24.Size = New System.Drawing.Size(325, 38)
        Me.Button24.TabIndex = 2
        Me.Button24.Text = "Cadastrar Usuario"
        Me.Button24.UseVisualStyleBackColor = True
        '
        'Button25
        '
        Me.Button25.Location = New System.Drawing.Point(68, 145)
        Me.Button25.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Button25.Name = "Button25"
        Me.Button25.Size = New System.Drawing.Size(180, 38)
        Me.Button25.TabIndex = 1
        Me.Button25.Text = "JSON DE EXEMPLO"
        Me.Button25.UseVisualStyleBackColor = True
        '
        'tabPage8
        '
        Me.tabPage8.BackColor = System.Drawing.Color.White
        Me.tabPage8.Controls.Add(Me.Label27)
        Me.tabPage8.Controls.Add(Me.webhookid)
        Me.tabPage8.Controls.Add(Me.Button33)
        Me.tabPage8.Controls.Add(Me.Button34)
        Me.tabPage8.Controls.Add(Me.Button27)
        Me.tabPage8.Controls.Add(Me.Button28)
        Me.tabPage8.Controls.Add(Me.Button29)
        Me.tabPage8.Controls.Add(Me.Button30)
        Me.tabPage8.Controls.Add(Me.Button31)
        Me.tabPage8.Controls.Add(Me.Button32)
        Me.tabPage8.ForeColor = System.Drawing.Color.Black
        Me.tabPage8.Location = New System.Drawing.Point(4, 34)
        Me.tabPage8.Name = "tabPage8"
        Me.tabPage8.Padding = New System.Windows.Forms.Padding(3)
        Me.tabPage8.Size = New System.Drawing.Size(730, 1036)
        Me.tabPage8.TabIndex = 7
        Me.tabPage8.Text = "Webhook"
        '
        'Button27
        '
        Me.Button27.Location = New System.Drawing.Point(274, 301)
        Me.Button27.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Button27.Name = "Button27"
        Me.Button27.Size = New System.Drawing.Size(325, 38)
        Me.Button27.TabIndex = 42
        Me.Button27.Text = "Atualizar WebHook (PUT)"
        Me.Button27.UseVisualStyleBackColor = True
        '
        'Button28
        '
        Me.Button28.Location = New System.Drawing.Point(86, 301)
        Me.Button28.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Button28.Name = "Button28"
        Me.Button28.Size = New System.Drawing.Size(180, 38)
        Me.Button28.TabIndex = 41
        Me.Button28.Text = "JSON DE EXEMPLO"
        Me.Button28.UseVisualStyleBackColor = True
        '
        'Button29
        '
        Me.Button29.Location = New System.Drawing.Point(86, 434)
        Me.Button29.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Button29.Name = "Button29"
        Me.Button29.Size = New System.Drawing.Size(513, 38)
        Me.Button29.TabIndex = 40
        Me.Button29.Text = "Listar Webhook"
        Me.Button29.UseVisualStyleBackColor = True
        '
        'Button30
        '
        Me.Button30.Location = New System.Drawing.Point(383, 80)
        Me.Button30.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Button30.Name = "Button30"
        Me.Button30.Size = New System.Drawing.Size(291, 38)
        Me.Button30.TabIndex = 39
        Me.Button30.Text = "Orientação"
        Me.Button30.UseVisualStyleBackColor = True
        '
        'Button31
        '
        Me.Button31.Location = New System.Drawing.Point(274, 190)
        Me.Button31.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Button31.Name = "Button31"
        Me.Button31.Size = New System.Drawing.Size(325, 38)
        Me.Button31.TabIndex = 38
        Me.Button31.Text = "Cadastrar WebHook"
        Me.Button31.UseVisualStyleBackColor = True
        '
        'Button32
        '
        Me.Button32.Location = New System.Drawing.Point(86, 190)
        Me.Button32.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Button32.Name = "Button32"
        Me.Button32.Size = New System.Drawing.Size(180, 38)
        Me.Button32.TabIndex = 37
        Me.Button32.Text = "JSON DE EXEMPLO"
        Me.Button32.UseVisualStyleBackColor = True
        '
        'textoEntrada
        '
        Me.textoEntrada.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.textoEntrada.Location = New System.Drawing.Point(1277, 48)
        Me.textoEntrada.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.textoEntrada.Name = "textoEntrada"
        Me.textoEntrada.Size = New System.Drawing.Size(727, 503)
        Me.textoEntrada.TabIndex = 32
        Me.textoEntrada.Text = ""
        '
        'label15
        '
        Me.label15.AutoSize = True
        Me.label15.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, CType(((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic) _
                Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point)
        Me.label15.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.label15.Location = New System.Drawing.Point(1277, 18)
        Me.label15.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label15.Name = "label15"
        Me.label15.Size = New System.Drawing.Size(291, 25)
        Me.label15.TabIndex = 31
        Me.label15.Text = "ENTRADA DA REQUISIÇÃO"
        '
        'label13
        '
        Me.label13.AutoSize = True
        Me.label13.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, CType(((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic) _
                Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point)
        Me.label13.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.label13.Location = New System.Drawing.Point(1277, 556)
        Me.label13.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label13.Name = "label13"
        Me.label13.Size = New System.Drawing.Size(255, 25)
        Me.label13.TabIndex = 30
        Me.label13.Text = "SAIDA DA REQUISIÇÃO"
        '
        'label14
        '
        Me.label14.AutoSize = True
        Me.label14.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, CType(((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic) _
                Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point)
        Me.label14.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.label14.Location = New System.Drawing.Point(780, 18)
        Me.label14.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.label14.Name = "label14"
        Me.label14.Size = New System.Drawing.Size(261, 25)
        Me.label14.TabIndex = 29
        Me.label14.Text = "AUXILIO DE EXECUÇÃO"
        '
        'textoOrientacao
        '
        Me.textoOrientacao.BackColor = System.Drawing.SystemColors.HighlightText
        Me.textoOrientacao.Location = New System.Drawing.Point(780, 48)
        Me.textoOrientacao.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.textoOrientacao.Name = "textoOrientacao"
        Me.textoOrientacao.Size = New System.Drawing.Size(480, 1045)
        Me.textoOrientacao.TabIndex = 28
        Me.textoOrientacao.Text = ""
        '
        'textoResposta
        '
        Me.textoResposta.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.textoResposta.Location = New System.Drawing.Point(1277, 578)
        Me.textoResposta.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.textoResposta.Name = "textoResposta"
        Me.textoResposta.Size = New System.Drawing.Size(727, 510)
        Me.textoResposta.TabIndex = 27
        Me.textoResposta.Text = ""
        '
        'openCertificado
        '
        Me.openCertificado.Filter = "Certificado (*.csr;*.pfx;*.p12;)|*.csr;*.pfx;*.p12;"
        '
        'Button33
        '
        Me.Button33.Location = New System.Drawing.Point(274, 376)
        Me.Button33.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Button33.Name = "Button33"
        Me.Button33.Size = New System.Drawing.Size(325, 38)
        Me.Button33.TabIndex = 44
        Me.Button33.Text = "Atualizar WebHook (PATCH)"
        Me.Button33.UseVisualStyleBackColor = True
        '
        'Button34
        '
        Me.Button34.Location = New System.Drawing.Point(86, 376)
        Me.Button34.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Button34.Name = "Button34"
        Me.Button34.Size = New System.Drawing.Size(180, 38)
        Me.Button34.TabIndex = 43
        Me.Button34.Text = "JSON DE EXEMPLO"
        Me.Button34.UseVisualStyleBackColor = True
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(72, 242)
        Me.Label27.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(115, 25)
        Me.Label27.TabIndex = 48
        Me.Label27.Text = "WebHook ID"
        '
        'webhookid
        '
        Me.webhookid.Location = New System.Drawing.Point(73, 260)
        Me.webhookid.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.webhookid.Name = "webhookid"
        Me.webhookid.Size = New System.Drawing.Size(544, 31)
        Me.webhookid.TabIndex = 47
        '
        'Button35
        '
        Me.Button35.Location = New System.Drawing.Point(256, 346)
        Me.Button35.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Button35.Name = "Button35"
        Me.Button35.Size = New System.Drawing.Size(325, 38)
        Me.Button35.TabIndex = 48
        Me.Button35.Text = "Atualizar Usuario (PATCH)"
        Me.Button35.UseVisualStyleBackColor = True
        '
        'Button36
        '
        Me.Button36.Location = New System.Drawing.Point(68, 346)
        Me.Button36.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Button36.Name = "Button36"
        Me.Button36.Size = New System.Drawing.Size(180, 38)
        Me.Button36.TabIndex = 47
        Me.Button36.Text = "JSON DE EXEMPLO"
        Me.Button36.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(10.0!, 25.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(2023, 1122)
        Me.Controls.Add(Me.textoEntrada)
        Me.Controls.Add(Me.label15)
        Me.Controls.Add(Me.label13)
        Me.Controls.Add(Me.label14)
        Me.Controls.Add(Me.textoOrientacao)
        Me.Controls.Add(Me.textoResposta)
        Me.Controls.Add(Me.tabControl1)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form1"
        Me.tabControl1.ResumeLayout(False)
        Me.tabPage1.ResumeLayout(False)
        Me.tabPage1.PerformLayout()
        Me.tabPage2.ResumeLayout(False)
        Me.tabPage2.PerformLayout()
        Me.tabPage3.ResumeLayout(False)
        Me.tabPage3.PerformLayout()
        Me.tabPage4.ResumeLayout(False)
        Me.tabPage4.PerformLayout()
        Me.tabPage5.ResumeLayout(False)
        Me.tabPage5.PerformLayout()
        Me.Certificado.ResumeLayout(False)
        Me.Certificado.PerformLayout()
        Me.tabPage7.ResumeLayout(False)
        Me.tabPage7.PerformLayout()
        Me.tabPage8.ResumeLayout(False)
        Me.tabPage8.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Private WithEvents tabControl1 As TabControl
    Private WithEvents tabPage1 As TabPage
    Private WithEvents label2 As Label
    Private WithEvents btnOrientacaoAutenticar As Button
    Private WithEvents label10 As Label
    Private WithEvents boxAcessTokenCompany As TextBox
    Private WithEvents label7 As Label
    Private WithEvents boxAcessTokenSh As TextBox
    Private WithEvents btnAutenticaExemploCompany As Button
    Private WithEvents btnExemploSh As Button
    Private WithEvents label5 As Label
    Private WithEvents label6 As Label
    Private WithEvents boxCompanyClientSecret As TextBox
    Private WithEvents boxCompanyClientID As TextBox
    Private WithEvents btnAutenticaCompany As Button
    Private WithEvents btnAutenticaSh As Button
    Private WithEvents label4 As Label
    Private WithEvents label3 As Label
    Private WithEvents boxShSenha As TextBox
    Private WithEvents boxShEmail As TextBox
    Private WithEvents label1 As Label
    Private WithEvents optionProduction As RadioButton
    Private WithEvents optionStaging As RadioButton
    Private WithEvents tabPage2 As TabPage
    Private WithEvents button6 As Button
    Private WithEvents button7 As Button
    Private WithEvents label17 As Label
    Private WithEvents edtcompanyput As TextBox
    Private WithEvents button2 As Button
    Private WithEvents button5 As Button
    Private WithEvents label16 As Label
    Private WithEvents edtcompanypatch As TextBox
    Private WithEvents AtualizarCompanyPut As Button
    Private WithEvents button4 As Button
    Private WithEvents button1 As Button
    Private WithEvents btnOrientacaoCompany As Button
    Private WithEvents label8 As Label
    Private WithEvents boxIdCompany As TextBox
    Private WithEvents btnCadastrarCompany As Button
    Private WithEvents btnExemploCompany As Button
    Private WithEvents tabPage3 As TabPage
    Private WithEvents button13 As Button
    Private WithEvents label19 As Label
    Private WithEvents edtaccountput As TextBox
    Private WithEvents button11 As Button
    Private WithEvents button12 As Button
    Private WithEvents label18 As Label
    Private WithEvents edtaccountpatch As TextBox
    Private WithEvents button9 As Button
    Private WithEvents button10 As Button
    Private WithEvents button8 As Button
    Private WithEvents btnOrientacaoConta As Button
    Private WithEvents label9 As Label
    Private WithEvents boxIdConta As TextBox
    Private WithEvents btnCadConta As Button
    Private WithEvents btnExemploConta As Button
    Private WithEvents tabPage4 As TabPage
    Private WithEvents label20 As Label
    Private WithEvents BoxPixCharge As TextBox
    Private WithEvents button17 As Button
    Private WithEvents button18 As Button
    Private WithEvents label21 As Label
    Private WithEvents textBox2 As TextBox
    Private WithEvents btnEmitirCobrançacomVencimento As Button
    Private WithEvents button20 As Button
    Private WithEvents btnOrientacaoPix As Button
    Private WithEvents label12 As Label
    Private WithEvents boxUrlQrCode As TextBox
    Private WithEvents btnQrCode As Button
    Private WithEvents btnConsultPix As Button
    Private WithEvents label11 As Label
    Private WithEvents boxIdPix As TextBox
    Private WithEvents btnEmitirPix As Button
    Private WithEvents btnExemploPix As Button
    Private WithEvents tabPage5 As TabPage
    Private WithEvents button14 As Button
    Private WithEvents button15 As Button
    Private WithEvents button16 As Button
    Private WithEvents Certificado As TabPage
    Private WithEvents tabPage7 As TabPage
    Private WithEvents tabPage8 As TabPage
    Private WithEvents textoEntrada As RichTextBox
    Private WithEvents label15 As Label
    Private WithEvents label13 As Label
    Private WithEvents label14 As Label
    Private WithEvents textoOrientacao As RichTextBox
    Private WithEvents textoResposta As RichTextBox
    Private WithEvents Button3 As Button
    Private WithEvents Label22 As Label
    Private WithEvents boxIDPagamento As TextBox
    Private WithEvents Button19 As Button
    Private WithEvents Button21 As Button
    Private WithEvents Button22 As Button
    Private WithEvents Button23 As Button
    Private WithEvents Button24 As Button
    Private WithEvents Button25 As Button
    Friend WithEvents openCertificado As OpenFileDialog
    Private WithEvents btntrocarcertificado As Button
    Private WithEvents btnuploadcertificado As Button
    Private WithEvents btnlistarcertificados As Button
    Private WithEvents Label23 As Label
    Private WithEvents txtCertificado As TextBox
    Friend WithEvents btnSelecionarCertificado As Button
    Private WithEvents senha As Label
    Private WithEvents txtSenhaCertificado As TextBox
    Private WithEvents Label24 As Label
    Private WithEvents txtExtension As TextBox
    Private WithEvents Label26 As Label
    Private WithEvents txtKey As TextBox
    Private WithEvents Label25 As Label
    Private WithEvents txtAccountId As TextBox
    Private WithEvents Button26 As Button
    Private WithEvents Button27 As Button
    Private WithEvents Button28 As Button
    Private WithEvents Button29 As Button
    Private WithEvents Button30 As Button
    Private WithEvents Button31 As Button
    Private WithEvents Button32 As Button
    Private WithEvents Label28 As Label
    Private WithEvents TextBoxUserID As TextBox
    Private WithEvents Button33 As Button
    Private WithEvents Button34 As Button
    Private WithEvents Label27 As Label
    Private WithEvents webhookid As TextBox
    Private WithEvents Button35 As Button
    Private WithEvents Button36 As Button
End Class
