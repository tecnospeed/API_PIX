import tkinter as tk
from tkinter import scrolledtext
import requests

def enviar_requisicao():
    url = "https://pix.tecnospeed.com.br/sandbox/pix/dynamic"

    payload = {
        "accountId": account_id.get(),
        "amount": float(amount.get()),
        "duration": int(duration.get()),
        "tags": tags.get().split(","),
        "description": description.get()
    }

    headers = {
        "Content-Type": "application/json",
        "user-agent": "Insomnia/2023.5.2",
        "Authorization": authorization.get()
    }

    response = requests.post(url, json=payload, headers=headers)

    response_text.delete(1.0, tk.END)
    response_text.insert(tk.END, response.text)


root = tk.Tk()
root.title("Envio de Requisição Pix")

tk.Label(root, text="Account ID:").pack()
account_id = tk.Entry(root)
account_id.pack()

tk.Label(root, text="Amount:").pack()
amount = tk.Entry(root)
amount.pack()

tk.Label(root, text="Duration:").pack()
duration = tk.Entry(root)
duration.pack()

tk.Label(root, text="Tags (separadas por vírgula):").pack()
tags = tk.Entry(root)
tags.pack()

tk.Label(root, text="Description:").pack()
description = tk.Entry(root)
description.pack()

tk.Label(root, text="Authorization Token:").pack()
authorization = tk.Entry(root)
authorization.pack()


send_button = tk.Button(root, text="Enviar Requisição", command=enviar_requisicao)
send_button.pack()


response_text = scrolledtext.ScrolledText(root, wrap=tk.WORD, width=40, height=10)
response_text.pack()


root.mainloop()